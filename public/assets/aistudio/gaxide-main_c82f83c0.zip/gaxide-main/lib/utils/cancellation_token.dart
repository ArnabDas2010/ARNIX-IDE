/// Thrown when an operation notices [CancellationToken.isCancelled] and
/// bails out cooperatively. Callers catch this specifically to show
/// "Cancelled" instead of treating it as a real failure.
class OperationCancelledException implements Exception {
  const OperationCancelledException();
  @override
  String toString() => 'Operation cancelled';
}

/// Cooperative cancellation for batch/long-running file & archive ops.
///
/// Nothing here can interrupt a single already-in-flight `dart:io` call
/// (there's no OS-level abort for that) — cancellation takes effect at
/// the next checkpoint the operation passes through. For a batch (delete
/// selected, paste multiple items), that's between items. For a single
/// large folder walk (recursive delete/copy), that's between files,
/// since progress already ticks per-file — so in practice cancellation
/// lands within a fraction of a second, not "next item" in the coarse
/// sense.
class CancellationToken {
  bool _cancelled = false;
  bool get isCancelled => _cancelled;

  void cancel() => _cancelled = true;

  /// Call at any natural checkpoint; throws to unwind the operation.
  void throwIfCancelled() {
    if (_cancelled) throw const OperationCancelledException();
  }
}
