package com.gax.ide

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextWatcher
import android.text.Editable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.common.StandardMethodCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory

/**
 * v1 scope, on purpose (see MainActivity.kt's comment on why this exists
 * at all — the short version: Flutter's own TextField genuinely can't
 * handle a 100KB+ file quickly, this is a documented framework
 * limitation, not something fixable from the Dart side):
 *
 * - No syntax highlighting. Large files already had highlighting
 *   disabled in the Flutter editor too (the 80KB threshold), so this
 *   isn't a new loss — implementing a native tokenizer/Spannable
 *   highlighter for 20+ languages is a separate, much bigger project.
 * - No undo/redo wired to the app's own UndoHistoryController. The
 *   keyboard's own undo gesture (most IMEs, e.g. Gboard, support one)
 *   still works; the app's Undo/Redo toolbar buttons do not act on
 *   this view.
 * - Uses Android's built-in monospace Typeface, not the user's chosen
 *   Google Font from Settings — bundling/loading arbitrary Google Fonts
 *   natively is extra work not included in this pass.
 * - Content only crosses the platform channel on demand (getText,
 *   called when Save is tapped) — never per-keystroke, which would
 *   reintroduce the exact "marshal 100KB+ on every change" cost this
 *   whole native path exists to avoid.
 */
class NativeCodeEditorView(
    context: Context,
    id: Int,
    creationParams: Map<String?, Any?>?,
    messenger: io.flutter.plugin.common.BinaryMessenger,
) : PlatformView {

    private val container: LinearLayout = LinearLayout(context)
    private val gutter: TextView = TextView(context)
    private val editText: EditText = EditText(context)
    private val gutterScroll: ScrollView = ScrollView(context)
    private val editScroll: ScrollView = ScrollView(context)
    private val horizontalScroll: HorizontalScrollView = HorizontalScrollView(context)
    private val channel: MethodChannel

    init {
        val initialText = creationParams?.get("text") as? String ?: ""
        val fontSizeSp = (creationParams?.get("fontSize") as? Number)?.toFloat() ?: 14f
        val readOnly = creationParams?.get("readOnly") as? Boolean ?: false
        val isDark = creationParams?.get("isDark") as? Boolean ?: true

        val bg = if (isDark) Color.parseColor("#1E1E1E") else Color.WHITE
        val fg = if (isDark) Color.parseColor("#D4D4D4") else Color.BLACK
        val gutterFg = if (isDark) Color.parseColor("#6E6E6E") else Color.GRAY

        // --- line-number gutter ---
        gutter.typeface = Typeface.MONOSPACE
        gutter.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp * 0.85f)
        gutter.setTextColor(gutterFg)
        gutter.setBackgroundColor(bg)
        gutter.gravity = Gravity.END
        gutter.setPadding(12, 12, 12, 12)
        gutter.setLineSpacing(fontSizeSp * 0.4f, 1f)
        gutter.text = lineNumbersFor(initialText)

        // --- the actual editable text ---
        editText.setText(initialText)
        editText.typeface = Typeface.MONOSPACE
        editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp)
        editText.setTextColor(fg)
        editText.setBackgroundColor(bg)
        editText.setPadding(12, 12, 24, 12)
        editText.setLineSpacing(fontSizeSp * 0.4f, 1f)
        editText.gravity = Gravity.TOP or Gravity.START
        editText.isSingleLine = false
        // Long lines scroll horizontally rather than soft-wrap — matches
        // the Flutter editor's own behavior (see code_editor.dart).
        editText.setHorizontallyScrolling(true)
        editText.isEnabled = !readOnly
        editText.isFocusable = !readOnly
        editText.isFocusableInTouchMode = !readOnly
        // Don't auto-grab focus (and so the keyboard) the instant this
        // view is created — that races with the platform view still
        // being composited into Flutter's texture on its first frame(s),
        // which is exactly the flicker/glitch this avoids. An explicit
        // tap to focus is standard practice for embedded native text
        // views for this reason.
        editText.clearFocus()
        // Flat background, no default EditText underline/box chrome.
        editText.background = null

        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                // Only the (cheap) line-count gutter redraws live —
                // never send the actual content anywhere on every
                // keystroke, which is exactly the cost this native path
                // exists to avoid.
                gutter.text = lineNumbersFor(s?.toString() ?: "")
            }
        })

        // Gutter and text scroll together — nested inside one shared
        // ScrollView each so a single scroll listener keeps them in
        // lockstep, same reasoning as the Flutter editor's own
        // single-shared-ScrollController gutter (see code_editor.dart's
        // class doc for why two independently-synced controllers drift).
        gutterScroll.addView(gutter)
        gutterScroll.isVerticalScrollBarEnabled = false
        gutterScroll.isEnabled = false // gutter never captures scroll gestures itself

        horizontalScroll.addView(editText)
        horizontalScroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        editScroll.addView(horizontalScroll)
        editScroll.viewTreeObserver.addOnScrollChangedListener {
            gutterScroll.scrollTo(0, editScroll.scrollY)
        }

        container.orientation = LinearLayout.HORIZONTAL
        container.setBackgroundColor(bg)
        container.addView(gutterScroll, LinearLayout.LayoutParams(measureGutterWidth(initialText, fontSizeSp, context), LinearLayout.LayoutParams.MATCH_PARENT))
        container.addView(editScroll, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))

        channel = MethodChannel(messenger, "com.gax.ide/native_editor_$id", StandardMethodCodec.INSTANCE)
        channel.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {
                "getText" -> result.success(editText.text?.toString() ?: "")
                "setFontSize" -> {
                    val size = (call.arguments as? Number)?.toFloat() ?: fontSizeSp
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                    gutter.setTextSize(TypedValue.COMPLEX_UNIT_SP, size * 0.85f)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun lineNumbersFor(text: String): String {
        val count = text.count { it == '\n' } + 1
        return (1..count).joinToString("\n")
    }

    /** Wide enough for the largest line number this file will show. */
    private fun measureGutterWidth(text: String, fontSizeSp: Float, context: Context): Int {
        val lineCount = text.count { it == '\n' } + 1
        val digits = lineCount.toString().length.coerceAtLeast(2)
        val density = context.resources.displayMetrics.density
        return ((digits * fontSizeSp * 0.65f + 24) * density).toInt()
    }

    override fun getView(): View = container

    override fun dispose() {
        channel.setMethodCallHandler(null)
    }
}

class NativeCodeEditorViewFactory(private val messenger: io.flutter.plugin.common.BinaryMessenger) :
    PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    override fun create(context: Context, id: Int, args: Any?): PlatformView {
        @Suppress("UNCHECKED_CAST")
        val params = args as? Map<String?, Any?>
        return NativeCodeEditorView(context, id, params, messenger)
    }
}
