import 'dart:convert';
import 'package:flutter/material.dart';
import 'dart:typed_data';
import '../models/file_entry.dart';
import '../models/saf_document.dart';
import '../services/file_service.dart';
import '../services/saf_service.dart';
import '../widgets/file_list_tile.dart';
import '../widgets/message_dialog.dart';
import '../widgets/progress_dialog.dart';
import 'editor_screen.dart';
import 'folder_picker_screen.dart';

/// One folder level inside a SAF tree (Android/data/<something>, or
/// wherever the granted tree points). Navigating into a subfolder pushes
/// a new instance of this same screen — same pattern as the normal file
/// manager, just backed by SafService instead of dart:io.
class SafBrowserScreen extends StatefulWidget {
  final String treeUri; // root of the whole granted tree — kept for reference/future use
  final String currentUri; // the folder THIS screen instance is showing
  final String title;

  const SafBrowserScreen({super.key, required this.treeUri, required this.currentUri, required this.title});

  @override
  State<SafBrowserScreen> createState() => _SafBrowserScreenState();
}

class _SafBrowserScreenState extends State<SafBrowserScreen> {
  final _saf = SafService();
  final _fileService = FileService();
  List<SafDocument> _entries = [];
  bool _loading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      final children = await _saf.listChildren(widget.currentUri);
      // Folders first, then alphabetical — matches the normal file
      // manager's default sort so this doesn't feel like a different app.
      children.sort((a, b) {
        if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
      if (mounted) setState(() => _entries = children);
    } catch (e) {
      if (mounted) setState(() => _loadError = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  FileEntry _asFileEntry(SafDocument doc) => FileEntry(
        name: doc.name,
        path: doc.uri, // not a real path — just needs to be a stable, unique string
        isDirectory: doc.isDirectory,
        sizeBytes: doc.size,
        modified: doc.lastModified > 0 ? DateTime.fromMillisecondsSinceEpoch(doc.lastModified) : DateTime.now(),
      );

  Future<void> _openEntry(SafDocument doc) async {
    if (doc.isDirectory) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => SafBrowserScreen(treeUri: widget.treeUri, currentUri: doc.uri, title: doc.name)),
      );
      return;
    }

    final busy = showBusyDialog(context, message: 'Opening ${doc.name}...');
    String? content;
    try {
      final bytes = await _saf.readBytes(doc.uri);
      content = await _fileService.decodeAndSanitize(bytes);
    } catch (e) {
      busy.close();
      if (mounted) showMessageDialog(context, 'Could not open: $e', isError: true);
      return;
    }
    busy.close();

    if (!mounted) return;
    final currentUri = doc.uri;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditorScreen(
          filePath: doc.name,
          initialContent: content!,
          onSaveOverride: (text) => _saf.writeBytes(currentUri, Uint8List.fromList(utf8.encode(text))),
        ),
      ),
    );
  }

  void _showEntryActions(SafDocument doc) {
    showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(leading: const Icon(Icons.drive_file_rename_outline_rounded), title: const Text('Rename'), onTap: () => Navigator.pop(ctx, 'rename')),
            if (!doc.isDirectory)
              ListTile(
                leading: const Icon(Icons.folder_copy_outlined),
                title: const Text('Copy to Workspace'),
                subtitle: const Text('Brings it into normal storage — full editor features work there'),
                onTap: () => Navigator.pop(ctx, 'copyout'),
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
              title: const Text('Delete'),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    ).then((action) async {
      switch (action) {
        case 'rename':
          await _renameEntry(doc);
          break;
        case 'copyout':
          await _copyToWorkspace(doc);
          break;
        case 'delete':
          await _deleteEntry(doc);
          break;
      }
    });
  }

  Future<void> _renameEntry(SafDocument doc) async {
    final controller = TextEditingController(text: doc.name);
    final newName = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Rename')),
        ],
      ),
    );
    if (newName == null || newName.isEmpty || newName == doc.name) return;
    try {
      await _saf.renameDocument(doc.uri, newName);
      _load();
    } catch (e) {
      if (mounted) showMessageDialog(context, 'Rename failed: $e', isError: true);
    }
  }

  Future<void> _deleteEntry(SafDocument doc) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete?'),
        content: Text('"${doc.name}" will be permanently deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await _saf.deleteDocument(doc.uri);
      _load();
    } catch (e) {
      if (mounted) showMessageDialog(context, 'Delete failed: $e', isError: true);
    }
  }

  Future<void> _copyToWorkspace(SafDocument doc) async {
    final destDir = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const FolderPickerScreen()));
    if (destDir == null || !mounted) return;

    final busy = showBusyDialog(context, message: 'Copying ${doc.name}...');
    try {
      final bytes = await _saf.readBytes(doc.uri);
      await _fileService.saveBytesToPath('$destDir/${doc.name}', bytes);
      busy.close();
      if (mounted) showMessageDialog(context, 'Copied to $destDir/${doc.name}');
    } catch (e) {
      busy.close();
      if (mounted) showMessageDialog(context, 'Copy failed: $e', isError: true);
    }
  }

  Future<void> _createFile() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New File'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'filename.txt')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    try {
      await _saf.createFile(widget.currentUri, name);
      _load();
    } catch (e) {
      if (mounted) showMessageDialog(context, 'Could not create file: $e', isError: true);
    }
  }

  Future<void> _createFolder() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    try {
      await _saf.createDirectory(widget.currentUri, name);
      _load();
    } catch (e) {
      if (mounted) showMessageDialog(context, 'Could not create folder: $e', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Could not list this folder: $_loadError', textAlign: TextAlign.center),
                  ),
                )
              : _entries.isEmpty
                  ? const Center(child: Text('Empty folder'))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(8),
                        itemCount: _entries.length,
                        itemBuilder: (context, i) {
                          final doc = _entries[i];
                          return FileListTile(
                            entry: _asFileEntry(doc),
                            onTap: () => _openEntry(doc),
                            onLongPress: () => _showEntryActions(doc),
                          );
                        },
                      ),
                    ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showModalBottomSheet<void>(
          context: context,
          builder: (ctx) => SafeArea(
            child: Wrap(
              children: [
                ListTile(
                  leading: const Icon(Icons.note_add_outlined),
                  title: const Text('New File'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _createFile();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.create_new_folder_outlined),
                  title: const Text('New Folder'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _createFolder();
                  },
                ),
              ],
            ),
          ),
        ),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}
