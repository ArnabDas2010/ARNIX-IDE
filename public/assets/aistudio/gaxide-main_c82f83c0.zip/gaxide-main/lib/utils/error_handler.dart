import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/message_dialog.dart';

/// Lets error handling reach a BuildContext from anywhere — including
/// global error callbacks that fire outside the normal widget build path.
final navigatorKey = GlobalKey<NavigatorState>();

/// Turns a handful of common, recognizable exceptions into a plain-language
/// first line. Anything unrecognized still gets a calm, honest fallback —
/// the raw text is never hidden, just not the FIRST thing shown, since
/// most people aren't going to parse a stack trace but everyone can
/// understand "that file couldn't be found."
String _friendlyMessage(Object error) {
  final text = error.toString();
  if (text.contains('SocketException') || text.contains('Connection') || text.contains('Network is unreachable')) {
    return "Couldn't connect to the internet. Check your connection and try again.";
  }
  if (text.contains('PathNotFoundException') || text.contains('No such file or directory')) {
    return "That file or folder couldn't be found — it may have been moved or deleted.";
  }
  if (text.contains('PathAccessException') || text.contains('Permission denied') || text.contains('errno = 13')) {
    return "Permission denied — GAX IDE doesn't have access to do this here.";
  }
  if (text.contains('FileSystemException') && text.contains('exists')) {
    return 'Something with that name already exists.';
  }
  if (text.toLowerCase().contains('out of memory') || text.contains('OutOfMemoryError')) {
    return 'Ran out of memory — try closing other apps or working with a smaller file.';
  }
  if (text.contains('FormatException')) {
    return "That file doesn't look like what was expected — it may be corrupted or in the wrong format.";
  }
  if (text.contains('TimeoutException')) {
    return 'That took too long and timed out. Please try again.';
  }
  if (text.contains('RenderFlex overflowed') || text.contains('RenderBox')) {
    return "A part of the screen didn't fit properly and couldn't be displayed.";
  }
  return 'Something went wrong. The technical details below might help figure out why.';
}

/// Guards against stacking multiple full-screen error dialogs — if two
/// errors fire close together (or several widgets error in the same
/// frame), only the first opens a dialog; the rest are still logged to
/// console via FlutterError.presentError/onError, just not each popping
/// their own non-dismissible-feeling dialog on top of one another.
bool _errorDialogShowing = false;

/// Layout-only errors (a Row/Column overflowing by a few pixels, an
/// unbounded-height error, etc.) are common, usually harmless, and can
/// fire repeatedly during a resize/rotation/animation — interrupting the
/// user with a full "Something Went Wrong" modal for these is jarring
/// and out of proportion. The inline red placeholder from
/// [ErrorWidget.builder] already shows exactly where the problem is
/// without blocking the rest of the screen, so that's left as the only
/// visible signal for this category. Anything else (a real thrown
/// exception during build, a null check failure, etc.) still gets the
/// full dialog — this only filters the two specific layout complaints
/// [_friendlyMessage] already recognizes as cosmetic.
bool _isLayoutOnlyError(Object error) {
  final text = error.toString();
  return text.contains('RenderFlex overflowed') || text.contains('RenderBox was not laid out');
}

void _showErrorDialog(Object error, StackTrace? stack) {
  if (_errorDialogShowing) return;
  if (_isLayoutOnlyError(error)) return;

  final context = navigatorKey.currentState?.overlay?.context;
  if (context == null) return;

  final rawDetails = stack != null ? '$error\n\n$stack' : '$error';

  _errorDialogShowing = true;
  showDialog<void>(
    context: context,
    builder: (ctx) {
      final scheme = Theme.of(ctx).colorScheme;
      return AlertDialog(
        icon: const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 32),
        title: const Text('Something Went Wrong'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_friendlyMessage(error)),
              const SizedBox(height: 14),
              Text(
                'Technical details',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: scheme.onSurfaceVariant),
              ),
              const SizedBox(height: 6),
              Container(
                constraints: const BoxConstraints(maxHeight: 160),
                width: double.maxFinite,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SingleChildScrollView(
                  child: SelectableText(rawDetails, style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton.icon(
            icon: const Icon(Icons.copy_rounded, size: 18),
            label: const Text('Copy Error'),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: rawDetails));
              if (ctx.mounted) {
                showMessageDialog(ctx, 'Error copied to clipboard');
              }
            },
          ),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Dismiss')),
        ],
      );
    },
  ).then((_) => _errorDialogShowing = false);
}

/// Compact inline replacement for a single broken widget subtree — shown
/// in place of Flutter's default red-and-black error screen when a
/// specific widget fails to build. Tapping "Copy Error" works the same
/// way as the full dialog.
class _InlineErrorPlaceholder extends StatelessWidget {
  final FlutterErrorDetails details;
  const _InlineErrorPlaceholder({required this.details});

  @override
  Widget build(BuildContext context) {
    final rawDetails = '${details.exception}\n\n${details.stack}';
    return Container(
      color: const Color(0xFF1A1A22),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 26),
          const SizedBox(height: 8),
          const Text(
            "This part of the screen couldn't be displayed.",
            style: TextStyle(color: Colors.white70, fontSize: 12.5),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 6),
          TextButton.icon(
            icon: const Icon(Icons.copy_rounded, size: 15, color: Colors.white60),
            label: const Text('Copy Error', style: TextStyle(color: Colors.white60, fontSize: 12.5)),
            onPressed: () => Clipboard.setData(ClipboardData(text: rawDetails)),
          ),
        ],
      ),
    );
  }
}

/// Wires up app-wide error handling exactly once, from main(). Replaces
/// three separate default Flutter behaviors:
/// - FlutterError.onError (framework build/layout/paint errors) — still
///   logs to console as normal, but ALSO shows the custom dialog.
/// - PlatformDispatcher.instance.onError (uncaught async errors) — same.
/// - ErrorWidget.builder — swaps Flutter's default red screen for a
///   small inline card, so a single broken widget never turns the
///   surrounding screen into a wall of red debug text.
void setupGlobalErrorHandling() {
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details); // keep normal console logging
    _showErrorDialog(details.exception, details.stack);
  };

  PlatformDispatcher.instance.onError = (error, stack) {
    _showErrorDialog(error, stack);
    return true;
  };

  ErrorWidget.builder = (details) => _InlineErrorPlaceholder(details: details);
}

/// Call from a try/catch anywhere in the app to show the exact same
/// dialog for a caught (not just uncaught) error — e.g. a file operation
/// that failed.
void showCaughtErrorDialog(Object error, [StackTrace? stack]) => _showErrorDialog(error, stack);
