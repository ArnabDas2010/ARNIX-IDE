import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

/// Thrown by [GithubService.fetchRemoteTree] for anything that ISN'T a
/// genuinely-empty repo — network failure, bad/expired token, wrong
/// branch name, no access, rate limit, etc. Previously all of these
/// quietly returned an empty map, indistinguishable from "this repo has
/// no commits yet", which made [GithubService.computeDiff] mark every
/// local file as "added" and show a misleading diff right before a
/// push — a wrong branch name or a dropped connection looked identical
/// to "first push to a brand-new repo".
class RemoteTreeFetchException implements Exception {
  final String message;
  const RemoteTreeFetchException(this.message);
  @override
  String toString() => message;
}

class GithubPushResult {
  final bool success;
  final String message;
  final String? commitSha;
  const GithubPushResult(this.success, this.message, {this.commitSha});
}

/// File and line-level summary of what a push changed — shown in the
/// result message after a push, and (for `.gaxide`-tracked projects)
/// saved into the project file as a quick local record.
class DiffStats {
  final int addedFiles;
  final int modifiedFiles;
  final int deletedFiles;
  final int linesAdded;
  final int linesRemoved;

  const DiffStats({
    required this.addedFiles,
    required this.modifiedFiles,
    required this.deletedFiles,
    required this.linesAdded,
    required this.linesRemoved,
  });

  int get totalFilesChanged => addedFiles + modifiedFiles + deletedFiles;
}

/// The result of comparing local files against the actual remote tree on
/// GitHub — by content hash, not timestamps, so it's correct even right
/// after a fresh copy/checkout where mtimes carry no meaning.
class FileDiff {
  final List<String> added;
  final List<String> modified;
  final List<String> deleted;
  final List<String> unchanged;

  const FileDiff({
    required this.added,
    required this.modified,
    required this.deleted,
    required this.unchanged,
  });

  int get changedCount => added.length + modified.length + deleted.length;
  bool get hasChanges => changedCount > 0;
}

/// Pushes an entire folder to GitHub as ONE atomic commit, using the Git
/// Data API (blobs -> tree -> commit -> branch ref update) instead of one
/// REST call per file — no git binary and no `.git` folder required.
///
/// Diffing against GitHub directly (rather than keeping our own local
/// "last push" snapshot) means this works identically whether the
/// project is tracked via a real `.git` folder or a `.gaxide` file: both
/// just need a repo/branch/token, and the actual source of truth for
/// "what changed" is always whatever's really on GitHub right now.
class GithubService {
  // Blob uploads carry real file content (not just small JSON metadata
  // like GithubApiService's calls), so this is longer than that
  // service's timeout — long enough for a slow mobile connection to
  // finish uploading a normal-sized source file, short enough that a
  // truly hung request still gives up instead of leaving the push
  // dialog frozen forever.
  static const _timeout = Duration(seconds: 30);
  /// Git's own content-addressing scheme for a blob:
  /// `sha1("blob " + byteLength + "\0" + content)`. Computing this
  /// locally lets a local file be compared directly against a remote
  /// blob SHA with no need to download the remote file's actual bytes.
  static String gitBlobSha1(List<int> content) {
    final header = utf8.encode('blob ${content.length}\u0000');
    return sha1.convert([...header, ...content]).toString();
  }

  Map<String, String> _headers(String token) => {
        'Authorization': 'token $token',
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
      };

  /// Fetches the full recursive file tree of [branch] as path -> blob
  /// SHA. Returns an empty map if the branch/repo has no commits yet (a
  /// brand-new empty repo) rather than treating that as an error — every
  /// local file then correctly shows up as "added".
  Future<Map<String, String>> fetchRemoteTree({
    required String token,
    required String owner,
    required String repo,
    required String branch,
  }) async {
    final headers = _headers(token);
    final base = 'https://api.github.com/repos/$owner/$repo';
    try {
      final refRes = await http.get(Uri.parse('$base/git/refs/heads/$branch'), headers: headers).timeout(_timeout);

      if (refRes.statusCode == 404) {
        // A 404 here means one of two very different things: (a) the
        // repo genuinely has no commits yet — safe to treat as "nothing
        // remote, everything local is new" — or (b) the repo has
        // commits, just not on THIS branch (typo, wrong default branch,
        // etc.), which must NOT be silently treated the same way. The
        // repo's own `size` field (KB) tells them apart: a truly fresh
        // repo is 0.
        final repoRes = await http.get(Uri.parse(base), headers: headers).timeout(_timeout);
        if (repoRes.statusCode != 200) {
          throw const RemoteTreeFetchException('Repository not found, or this token has no access to it.');
        }
        final repoSize = (jsonDecode(repoRes.body) as Map<String, dynamic>)['size'] as int? ?? 0;
        if (repoSize == 0) return {}; // genuinely empty repo — safe
        throw RemoteTreeFetchException('Branch "$branch" doesn\'t exist in $owner/$repo — check the branch name.');
      }
      if (refRes.statusCode == 401 || refRes.statusCode == 403) {
        throw RemoteTreeFetchException('GitHub rejected the request [${refRes.statusCode}] — check the token\'s permissions or rate limit.');
      }
      if (refRes.statusCode != 200) {
        throw RemoteTreeFetchException('Could not read "$branch" [${refRes.statusCode}].');
      }
      final commitSha = jsonDecode(refRes.body)['object']['sha'] as String;

      final commitRes = await http.get(Uri.parse('$base/git/commits/$commitSha'), headers: headers).timeout(_timeout);
      if (commitRes.statusCode != 200) {
        throw RemoteTreeFetchException('Could not read the latest commit [${commitRes.statusCode}].');
      }
      final treeSha = jsonDecode(commitRes.body)['tree']['sha'] as String;

      final treeRes = await http.get(Uri.parse('$base/git/trees/$treeSha?recursive=1'), headers: headers).timeout(_timeout);
      if (treeRes.statusCode != 200) {
        throw RemoteTreeFetchException('Could not read the remote file tree [${treeRes.statusCode}].');
      }
      final treeJson = jsonDecode(treeRes.body) as Map<String, dynamic>;
      final items = treeJson['tree'] as List<dynamic>;

      final result = <String, String>{};
      for (final item in items) {
        if (item['type'] == 'blob') {
          result[item['path'] as String] = item['sha'] as String;
        }
      }
      return result;
    } on RemoteTreeFetchException {
      rethrow;
    } catch (e) {
      // Network-level failures (no connection, DNS, timeout, etc.) —
      // these used to come back as an empty map too, indistinguishable
      // from an empty repo. Now they surface honestly instead of
      // quietly turning into "everything's new, go ahead and push".
      throw RemoteTreeFetchException('Could not reach GitHub: $e');
    }
  }

  /// Compares local files against a remote tree snapshot (see
  /// [fetchRemoteTree]).
  FileDiff computeDiff(List<MapEntry<String, List<int>>> localFiles, Map<String, String> remoteTree) {
    final added = <String>[];
    final modified = <String>[];
    final unchanged = <String>[];
    final localPaths = <String>{};

    for (final file in localFiles) {
      localPaths.add(file.key);
      final localSha = gitBlobSha1(file.value);
      final remoteSha = remoteTree[file.key];
      if (remoteSha == null) {
        added.add(file.key);
      } else if (remoteSha != localSha) {
        modified.add(file.key);
      } else {
        unchanged.add(file.key);
      }
    }

    final deleted = remoteTree.keys.where((p) => !localPaths.contains(p)).toList();
    return FileDiff(added: added, modified: modified, deleted: deleted, unchanged: unchanged);
  }

  /// Pushes [diff]'s changes as one commit. Only files marked
  /// added/modified are actually uploaded as new blobs — unchanged files
  /// are left untouched via `base_tree`, and deleted ones get an explicit
  /// `sha: null` tree entry so GitHub removes them too. Handles a
  /// brand-new empty repo/branch (no prior commits) by creating the ref
  /// instead of patching it.
  Future<GithubPushResult> pushFolder({
    required String token,
    required String owner,
    required String repo,
    required String branch,
    required List<MapEntry<String, List<int>>> files,
    required FileDiff diff,
    required String commitMessage,
    String authorName = 'GAX IDE',
    void Function(double progress)? onProgress,
  }) async {
    final headers = _headers(token);
    final base = 'https://api.github.com/repos/$owner/$repo';

    if (!diff.hasChanges) {
      return const GithubPushResult(false, 'Nothing changed since the last push.');
    }

    try {
      String? baseCommitSha;
      String? baseTreeSha;

      final refRes = await http.get(Uri.parse('$base/git/refs/heads/$branch'), headers: headers).timeout(_timeout);
      final isFreshBranch = refRes.statusCode != 200;

      if (!isFreshBranch) {
        baseCommitSha = jsonDecode(refRes.body)['object']['sha'] as String;
        final commitRes = await http.get(Uri.parse('$base/git/commits/$baseCommitSha'), headers: headers).timeout(_timeout);
        if (commitRes.statusCode != 200) {
          return GithubPushResult(false, '❌ Could not read base commit [${commitRes.statusCode}]');
        }
        baseTreeSha = jsonDecode(commitRes.body)['tree']['sha'] as String;
      }
      onProgress?.call(0.03);

      // Only upload files that actually changed — unchanged ones stay
      // exactly as they are in base_tree, so re-uploading them would
      // just waste requests and time for no reason.
      final changedPaths = {...diff.added, ...diff.modified};
      final filesToUpload = files.where((f) => changedPaths.contains(f.key)).toList();

      final treeItems = <Map<String, dynamic>>[];
      for (var i = 0; i < filesToUpload.length; i++) {
        final file = filesToUpload[i];
        final blobRes = await http.post(
          Uri.parse('$base/git/blobs'),
          headers: headers,
          body: jsonEncode({'content': base64Encode(file.value), 'encoding': 'base64'}),
        ).timeout(_timeout);
        if (blobRes.statusCode != 201) {
          return GithubPushResult(false, '❌ Failed uploading "${file.key}" [${blobRes.statusCode}]');
        }
        final blobSha = jsonDecode(blobRes.body)['sha'] as String;
        treeItems.add({'path': file.key, 'mode': '100644', 'type': 'blob', 'sha': blobSha});
        final denom = filesToUpload.isEmpty ? 1 : filesToUpload.length;
        onProgress?.call(0.05 + ((i + 1) / denom) * 0.70);
      }

      // Explicit deletions — sha: null tells the Trees API to remove
      // that path from the resulting tree instead of leaving it as-is.
      for (final path in diff.deleted) {
        treeItems.add({'path': path, 'mode': '100644', 'type': 'blob', 'sha': null});
      }
      onProgress?.call(0.78);

      final treeBody = <String, dynamic>{'tree': treeItems};
      if (baseTreeSha != null) treeBody['base_tree'] = baseTreeSha;

      final treeRes = await http.post(Uri.parse('$base/git/trees'), headers: headers, body: jsonEncode(treeBody)).timeout(_timeout);
      if (treeRes.statusCode != 201) {
        return GithubPushResult(false, '❌ Failed building tree [${treeRes.statusCode}]: ${treeRes.body}');
      }
      final newTreeSha = jsonDecode(treeRes.body)['sha'] as String;
      onProgress?.call(0.9);

      final commitBody = <String, dynamic>{
        'message': commitMessage,
        'tree': newTreeSha,
        'parents': baseCommitSha != null ? [baseCommitSha] : [],
        'author': {'name': authorName, 'email': _placeholderEmail(authorName)},
        'committer': {'name': authorName, 'email': _placeholderEmail(authorName)},
      };
      final commitCreateRes =
          await http.post(Uri.parse('$base/git/commits'), headers: headers, body: jsonEncode(commitBody)).timeout(_timeout);
      if (commitCreateRes.statusCode != 201) {
        return GithubPushResult(false, '❌ Failed creating commit [${commitCreateRes.statusCode}]');
      }
      final newCommitSha = jsonDecode(commitCreateRes.body)['sha'] as String;
      onProgress?.call(0.95);

      if (isFreshBranch) {
        final createRefRes = await http.post(
          Uri.parse('$base/git/refs'),
          headers: headers,
          body: jsonEncode({'ref': 'refs/heads/$branch', 'sha': newCommitSha}),
        ).timeout(_timeout);
        if (createRefRes.statusCode == 201) {
          onProgress?.call(1);
          return GithubPushResult(
            true,
            '🚀 Created "$branch" and pushed the first commit (${diff.changedCount} changes) to $owner/$repo.',
            commitSha: newCommitSha,
          );
        }
        return GithubPushResult(
          false,
          '❌ Failed creating branch ref [${createRefRes.statusCode}]: ${createRefRes.body}',
        );
      }

      final updateRefRes = await http.patch(
        Uri.parse('$base/git/refs/heads/$branch'),
        headers: headers,
        body: jsonEncode({'sha': newCommitSha}),
      ).timeout(_timeout);
      if (updateRefRes.statusCode == 200) {
        onProgress?.call(1);
        return GithubPushResult(
          true,
          '🚀 Pushed ${diff.changedCount} changed file(s) to $owner/$repo ($branch) in 1 commit.',
          commitSha: newCommitSha,
        );
      }
      return GithubPushResult(false, '❌ Failed updating branch ref [${updateRefRes.statusCode}]');
    } catch (e) {
      return GithubPushResult(false, '❌ Network Exception: $e');
    }
  }

  /// Best-effort commit-author email so the "author" object is valid even
  /// though only a display name is collected from the user.
  String _placeholderEmail(String name) {
    final slug =
        name.trim().isEmpty ? 'gax-ide' : name.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-');
    return '$slug@users.noreply.github.com';
  }

  /// Auto-fetches the PAT's own GitHub login, used to pre-fill the setup
  /// dialog's "Username" field whenever possible.
  Future<String?> fetchAuthenticatedUsername(String token) async {
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/user'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github.v3+json'},
      ).timeout(_timeout);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        return data['login'] as String?;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  // A push touching more files than this skips line-level counting
  // entirely (still reports file counts) — fetching each changed file's
  // old content is one extra API call per file, which isn't worth it for
  // a huge push just to produce a +/- number.
  static const _maxFilesForLineStats = 60;

  /// Builds the file + line +/- summary shown after a push. Line counts
  /// need each modified/deleted file's PREVIOUS content, fetched fresh
  /// from GitHub by blob SHA (already known from [remoteTree] — no extra
  /// tree walk needed). Best-effort throughout: a fetch failure or a
  /// binary file just quietly contributes 0 lines rather than failing
  /// the whole summary — the file-level counts are always accurate
  /// regardless.
  Future<DiffStats> computeDiffStats({
    required String token,
    required String owner,
    required String repo,
    required List<MapEntry<String, List<int>>> localFiles,
    required Map<String, String> remoteTree,
    required FileDiff diff,
  }) async {
    var linesAdded = 0;
    var linesRemoved = 0;

    if (diff.changedCount <= _maxFilesForLineStats) {
      final localByPath = {for (final f in localFiles) f.key: f.value};

      for (final path in diff.added) {
        final content = localByPath[path];
        if (content == null || !_looksLikeText(content)) continue;
        linesAdded += _lineCount(content);
      }

      for (final path in diff.deleted) {
        final sha = remoteTree[path];
        if (sha == null) continue;
        final oldBytes = await _fetchBlobContent(token, owner, repo, sha);
        if (oldBytes == null || !_looksLikeText(oldBytes)) continue;
        linesRemoved += _lineCount(oldBytes);
      }

      for (final path in diff.modified) {
        final sha = remoteTree[path];
        final newContent = localByPath[path];
        if (sha == null || newContent == null) continue;
        final oldBytes = await _fetchBlobContent(token, owner, repo, sha);
        if (oldBytes == null || !_looksLikeText(oldBytes) || !_looksLikeText(newContent)) continue;
        final counts = _lineDiffCounts(oldBytes, newContent);
        linesAdded += counts.$1;
        linesRemoved += counts.$2;
      }
    }

    return DiffStats(
      addedFiles: diff.added.length,
      modifiedFiles: diff.modified.length,
      deletedFiles: diff.deleted.length,
      linesAdded: linesAdded,
      linesRemoved: linesRemoved,
    );
  }

  Future<List<int>?> _fetchBlobContent(String token, String owner, String repo, String sha) async {
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/repos/$owner/$repo/git/blobs/$sha'),
        headers: _headers(token),
      ).timeout(_timeout);
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final content = data['content'] as String?;
      if (content == null) return null;
      return base64Decode(content.replaceAll('\n', ''));
    } catch (_) {
      return null;
    }
  }

  bool _looksLikeText(List<int> bytes) {
    if (bytes.isEmpty) return true;
    final sampleSize = bytes.length < 8000 ? bytes.length : 8000;
    for (var i = 0; i < sampleSize; i++) {
      if (bytes[i] == 0) return false; // a null byte essentially never appears in real text
    }
    return true;
  }

  int _lineCount(List<int> bytes) {
    try {
      final text = utf8.decode(bytes, allowMalformed: true);
      if (text.isEmpty) return 0;
      return '\n'.allMatches(text).length + (text.endsWith('\n') ? 0 : 1);
    } catch (_) {
      return 0;
    }
  }

  /// Approximates added/removed line counts via a multiset (line
  /// frequency) comparison rather than a full LCS/Myers diff — enough
  /// for a quick +/- summary number without needing a diff library, at
  /// the cost of not being a byte-perfect diff for heavily reordered
  /// content (rare for typical small edits).
  (int, int) _lineDiffCounts(List<int> oldBytes, List<int> newBytes) {
    try {
      final oldLines = utf8.decode(oldBytes, allowMalformed: true).split('\n');
      final newLines = utf8.decode(newBytes, allowMalformed: true).split('\n');

      final oldFreq = <String, int>{};
      for (final line in oldLines) {
        oldFreq[line] = (oldFreq[line] ?? 0) + 1;
      }
      final newFreq = <String, int>{};
      for (final line in newLines) {
        newFreq[line] = (newFreq[line] ?? 0) + 1;
      }

      var added = 0;
      var removed = 0;
      for (final key in {...oldFreq.keys, ...newFreq.keys}) {
        final o = oldFreq[key] ?? 0;
        final n = newFreq[key] ?? 0;
        if (n > o) added += n - o;
        if (o > n) removed += o - n;
      }
      return (added, removed);
    } catch (_) {
      return (0, 0);
    }
  }
}
