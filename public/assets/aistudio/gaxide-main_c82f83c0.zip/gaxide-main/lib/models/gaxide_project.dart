/// The `.gaxide` file's contents — a lightweight, git-independent
/// alternative to a `.git` folder for GitHub push. Created by "Git Init /
/// Make GitHub Project" when the user chooses NOT to use an existing (or
/// missing) `.git` folder.
///
/// The `last*` fields are written back after every successful push (only
/// for `.gaxide`-tracked projects — git-tracked projects already have
/// this history in git's own commit log, so nothing is duplicated there).
/// Diffing itself never depends on these — pushes always diff directly
/// against the real GitHub tree — this is purely a convenient local
/// record of what last went out.
class GaxideProject {
  final String name;
  final String repo; // "owner/repo-name"
  final String branch;
  final String username;
  final String createdAt;
  final String? lastCommitMessage;
  final String? lastCommitSha;
  final String? lastPushTime;
  final int? lastFilesChanged;
  final int? lastLinesAdded;
  final int? lastLinesRemoved;

  const GaxideProject({
    required this.name,
    required this.repo,
    required this.branch,
    required this.username,
    required this.createdAt,
    this.lastCommitMessage,
    this.lastCommitSha,
    this.lastPushTime,
    this.lastFilesChanged,
    this.lastLinesAdded,
    this.lastLinesRemoved,
  });

  String get owner => repo.contains('/') ? repo.split('/').first : '';
  String get repoName => repo.contains('/') ? repo.split('/').last : repo;

  GaxideProject copyWithLastPush({
    required String commitMessage,
    required String commitSha,
    required String pushTime,
    required int filesChanged,
    required int linesAdded,
    required int linesRemoved,
  }) {
    return GaxideProject(
      name: name,
      repo: repo,
      branch: branch,
      username: username,
      createdAt: createdAt,
      lastCommitMessage: commitMessage,
      lastCommitSha: commitSha,
      lastPushTime: pushTime,
      lastFilesChanged: filesChanged,
      lastLinesAdded: linesAdded,
      lastLinesRemoved: linesRemoved,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'repo': repo,
        'branch': branch,
        'username': username,
        'createdAt': createdAt,
        if (lastCommitMessage != null) 'lastCommitMessage': lastCommitMessage,
        if (lastCommitSha != null) 'lastCommitSha': lastCommitSha,
        if (lastPushTime != null) 'lastPushTime': lastPushTime,
        if (lastFilesChanged != null) 'lastFilesChanged': lastFilesChanged,
        if (lastLinesAdded != null) 'lastLinesAdded': lastLinesAdded,
        if (lastLinesRemoved != null) 'lastLinesRemoved': lastLinesRemoved,
      };

  factory GaxideProject.fromJson(Map<String, dynamic> json) => GaxideProject(
        name: json['name'] as String? ?? '',
        repo: json['repo'] as String? ?? '',
        branch: json['branch'] as String? ?? 'main',
        username: json['username'] as String? ?? 'GAX IDE',
        createdAt: json['createdAt'] as String? ?? '',
        lastCommitMessage: json['lastCommitMessage'] as String?,
        lastCommitSha: json['lastCommitSha'] as String?,
        lastPushTime: json['lastPushTime'] as String?,
        lastFilesChanged: json['lastFilesChanged'] as int?,
        lastLinesAdded: json['lastLinesAdded'] as int?,
        lastLinesRemoved: json['lastLinesRemoved'] as int?,
      );
}
