import 'package:flutter/material.dart';
import '../utils/cancellation_token.dart';

/// Shared close-race fix for both handles below: [showDialog]'s builder
/// isn't guaranteed to have run (and so `dialogContext` isn't
/// guaranteed to be set) by the time the *very* first progress tick
/// comes back — a real risk here specifically, since several callers
/// await no more than a single fast `dart:io` call per item. Without
/// this, calling close() in that gap is a silent no-op and the
/// non-dismissible dialog is then stuck on screen forever with no way
/// for the user to back out of it.
mixin _DialogLifecycle {
  BuildContext? dialogContext;
  bool _closeRequested = false;

  void onBuilt(BuildContext ctx) {
    dialogContext = ctx;
    if (_closeRequested) _popNow();
  }

  void requestClose() {
    _closeRequested = true;
    if (dialogContext != null) _popNow();
  }

  void _popNow() {
    final ctx = dialogContext;
    dialogContext = null;
    if (ctx != null && Navigator.canPop(ctx)) {
      Navigator.pop(ctx);
    }
  }
}

/// Lets the caller push updates into an already-shown [ProgressDialog]
/// without needing a StatefulWidget of its own at the call site — just
/// call [update] as work completes and [close] when done.
class ProgressDialogHandle with _DialogLifecycle {
  final ValueNotifier<double> _progress = ValueNotifier(0);
  final ValueNotifier<String> _detail = ValueNotifier('');
  final ValueNotifier<bool> _cancelling = ValueNotifier(false);
  final CancellationToken? cancelToken;

  ProgressDialogHandle({this.cancelToken});

  /// [value] is 0.0-1.0. [detail] (optional) shows under the title —
  /// e.g. the name of the item currently being processed in a batch.
  void update(double value, {String? detail}) {
    _progress.value = value.clamp(0.0, 1.0);
    if (detail != null) _detail.value = detail;
  }

  /// User tapped Cancel: flips the token (the running operation notices
  /// it at its next per-item checkpoint) and switches the dialog into a
  /// "Cancelling…" state so it's clear the tap registered even though
  /// the dialog itself doesn't close immediately — the caller still owns
  /// closing it once the operation actually unwinds, so partial state
  /// (e.g. "3 of 10 deleted") never gets misreported as complete.
  void _requestCancel() {
    cancelToken?.cancel();
    _cancelling.value = true;
  }

  void close() => requestClose();
}

/// A handle to a [showBusyDialog] — call [close] once the operation it's
/// covering finishes.
class BusyDialogHandle with _DialogLifecycle {
  void close() => requestClose();
}

/// Shows a small, non-dismissible "this is working" dialog with an
/// indeterminate spinner — for single-shot operations with no meaningful
/// percentage (opening a file, for instance: it's one read, not a batch
/// of countable steps). Since the actual work is expected to run on a
/// background isolate (see FileService.readFileAsString), the UI thread
/// stays free the whole time, so this spinner animates smoothly instead
/// of the app looking frozen while the file loads.
BusyDialogHandle showBusyDialog(BuildContext context, {required String message}) {
  final handle = BusyDialogHandle();
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) {
      handle.onBuilt(ctx);
      return PopScope(
        canPop: false,
        child: AlertDialog(
          content: Row(
            children: [
              const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)),
              const SizedBox(width: 18),
              Expanded(child: Text(message)),
            ],
          ),
        ),
      );
    },
  );
  return handle;
}

/// Shows a non-dismissible modal progress dialog with a percentage —
/// used for copy/move/delete/compress/extract, anything that might take
/// a moment on a large file or folder. Returns a handle to push progress
/// updates into it; always call [ProgressDialogHandle.close] in a
/// `finally` block once the operation finishes (success, failure, or
/// cancellation).
///
/// Pass [cancelToken] to show a Cancel button — do this for any batch or
/// folder-walk operation, since those have real per-item checkpoints the
/// running code can bail out at (see [CancellationToken]). Leave it null
/// for a genuinely atomic single step with no safe halfway point.
ProgressDialogHandle showProgressDialog(
  BuildContext context, {
  required String title,
  CancellationToken? cancelToken,
}) {
  final handle = ProgressDialogHandle(cancelToken: cancelToken);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) {
      handle.onBuilt(ctx);
      final scheme = Theme.of(ctx).colorScheme;
      return PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text(title),
          content: ValueListenableBuilder<double>(
            valueListenable: handle._progress,
            builder: (context, value, _) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ValueListenableBuilder<bool>(
                    valueListenable: handle._cancelling,
                    builder: (context, cancelling, __) {
                      if (!cancelling) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          'Cancelling — finishing current item…',
                          style: TextStyle(fontSize: 12.5, color: scheme.error, fontWeight: FontWeight.w600),
                        ),
                      );
                    },
                  ),
                  ValueListenableBuilder<String>(
                    valueListenable: handle._detail,
                    builder: (context, detail, __) {
                      if (detail.isEmpty) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          detail,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
                        ),
                      );
                    },
                  ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(value: value, minHeight: 8),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${(value * 100).clamp(0, 100).toStringAsFixed(0)}%',
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                      ),
                      if (cancelToken != null)
                        ValueListenableBuilder<bool>(
                          valueListenable: handle._cancelling,
                          builder: (context, cancelling, __) {
                            return TextButton(
                              // Touch target stays >=48dp via TextButton's
                              // default padding/minimumSize — no custom
                              // sizing needed here.
                              onPressed: cancelling ? null : handle._requestCancel,
                              child: Text(cancelling ? 'Cancelling…' : 'Cancel'),
                            );
                          },
                        ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),
      );
    },
  );
  return handle;
}
