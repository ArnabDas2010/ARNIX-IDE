import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import '../models/file_entry.dart';
import '../utils/cancellation_token.dart';

/// Runs on a background isolate via [compute] — reads the file and
/// sanitizes its content, keeping that (always at least O(n), sometimes
/// slow for a large file) work off the UI thread entirely. Without this,
/// the whole app appears to freeze — including any loading spinner,
/// which needs the UI thread free just to animate — for as long as a
/// big file takes to read. Must be a top-level function (not a method):
/// `compute` sends it to a fresh isolate, which can't see instance state.
Future<String> _readAndSanitizeOnIsolate(String path) async {
  final raw = await File(path).readAsString();
  return FileService.sanitizeForTextRendering(raw);
}

/// Same isolate-offload as [_readAndSanitizeOnIsolate], for content that
/// already arrived as raw bytes (e.g. a SAF read over a platform channel,
/// which has no real file path FileService can open itself) rather than
/// a path to read from disk.
String _decodeAndSanitizeOnIsolate(Uint8List bytes) {
  return FileService.sanitizeForTextRendering(utf8.decode(bytes, allowMalformed: true));
}

/// Direct raw-filesystem access (no SAF/file_picker cache-copy limitations).
/// Requires "All files access" on Android 11+ — grabbed via [ensureStoragePermission].
class FileService {
  /// Common Android shared-storage root. Works on the vast majority of devices.
  static const String rootStoragePath = '/storage/emulated/0';

  /// Folders skipped entirely when collecting files for a GitHub push —
  /// build artifacts / dependency caches nobody wants committed.
  static const List<String> ignoredDirNames = [
    '.git',
    'node_modules',
    'build',
    '.dart_tool',
    '.gradle',
    '.idea',
    '.vscode',
    'Pods',
    'dist',
    'out',
    'target',
    '__pycache__',
    '.venv',
    'venv',
    '.next',
  ];

  Future<bool> ensureStoragePermission() async {
    if (!Platform.isAndroid) return true;
    var status = await Permission.manageExternalStorage.status;
    if (status.isGranted) return true;
    status = await Permission.manageExternalStorage.request();
    return status.isGranted;
  }

  Future<void> openAppSettingsPage() => openAppSettings();

  /// Best-effort SD-card / secondary-storage detection. Android exposes no
  /// clean "list storage volumes" API without native code, so this uses the
  /// well-known heuristic: getExternalStorageDirectories() returns one
  /// per-volume app-specific folder (…/Android/data/<pkg>/files); stripping
  /// that suffix off any volume beyond the first (internal) one gives the
  /// SD card's root, e.g. /storage/1234-5678.
  Future<String?> detectSecondaryStoragePath() async {
    if (!Platform.isAndroid) return null;
    try {
      final dirs = await getExternalStorageDirectories();
      if (dirs == null || dirs.length < 2) return null;
      for (final dir in dirs.skip(1)) {
        final idx = dir.path.indexOf('/Android/data');
        if (idx == -1) continue;
        final root = dir.path.substring(0, idx);
        if (await Directory(root).exists()) return root;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// Lists a directory: folders first, then files, both alphabetical.
  /// Silently skips hidden entries and anything unreadable (e.g. system-locked).
  /// Each directory is also checked for a `.git` folder so the UI can badge it.
  Future<List<FileEntry>> listDirectory(String dirPath, {bool showHidden = false}) async {
    final dir = Directory(dirPath);
    final entries = <FileEntry>[];

    await for (final entity in dir.list(followLinks: false)) {
      final name = entity.path.split('/').last;
      if (!showHidden && name.startsWith('.')) continue;
      try {
        final stat = await entity.stat();
        final isDir = entity is Directory;
        var isGitRepo = false;
        if (isDir) {
          isGitRepo = await Directory('${entity.path}/.git').exists();
        }
        entries.add(FileEntry(
          name: name,
          path: entity.path,
          isDirectory: isDir,
          sizeBytes: stat.size,
          modified: stat.modified,
          isGitRepo: isGitRepo,
        ));
      } catch (_) {
        continue;
      }
    }

    entries.sort((a, b) {
      if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    return entries;
  }

  Future<String> readFileAsString(String path) => compute(_readAndSanitizeOnIsolate, path);

  /// Same as [readFileAsString] but for bytes that didn't come from a
  /// path FileService can open itself — e.g. a SAF read over a platform
  /// channel (see SafService.readBytes).
  ///
  /// Below [_isolateOffloadThreshold], this runs directly instead of
  /// through compute() — spawning a fresh isolate has its own real,
  /// non-trivial startup cost (worse on this app's low-end target
  /// hardware), and for a small file that cost was bigger than the
  /// sanitize work it was supposedly offloading. A typical SAF file
  /// (app prefs, small config/JSON) is well under this threshold, so
  /// this is the common case, not the exception.
  static const _isolateOffloadThreshold = 65536; // 64 KB

  Future<String> decodeAndSanitize(Uint8List bytes) {
    if (bytes.length < _isolateOffloadThreshold) {
      return Future.value(_decodeAndSanitizeOnIsolate(bytes));
    }
    return compute(_decodeAndSanitizeOnIsolate, bytes);
  }

  /// Strips EVERY UTF-16 surrogate code unit — replacing each with
  /// U+FFFD — not just unpaired/invalid ones. Two problems, one fix:
  ///
  /// 1. A file with an unusual encoding, a corrupted download, or bytes
  ///    from a non-standard tool can decode into a Dart String containing
  ///    LONE surrogates. Dart's String type doesn't itself require
  ///    well-formed UTF-16, so this reads fine — but Flutter's native
  ///    (Skia) text layer rejects it outright: "Invalid argument(s):
  ///    string is not well-formed UTF-16".
  /// 2. Even a source file that's perfectly well-formed can still trigger
  ///    the exact same crash *later*, during syntax highlighting: the
  ///    highlighter's regex-based tokenizer isn't necessarily surrogate-
  ///    aware, and can slice a VALID pair (an emoji, a rare CJK/math
  ///    character) into two separate text spans at the boundary between
  ///    its two halves — each half now a lone, invalid surrogate on its
  ///    own, in a completely different code path than file reading.
  ///
  /// The only way to make both classes of crash structurally impossible,
  /// rather than chasing them one call site at a time, is to remove
  /// surrogates from the text entirely at read time. The visible cost is
  /// that emoji/rare supplementary-plane characters render as a single
  /// placeholder glyph instead of themselves — a reasonable trade for a
  /// code/text editor, where such characters are rare and a crash is not
  /// an acceptable outcome. A single pass, so this stays cheap even for
  /// large files.
  static String sanitizeForTextRendering(String input) {
    StringBuffer? buffer; // only allocated if something actually needs fixing
    for (var i = 0; i < input.length; i++) {
      final code = input.codeUnitAt(i);
      final isHighSurrogate = code >= 0xD800 && code <= 0xDBFF;
      final isLowSurrogate = code >= 0xDC00 && code <= 0xDFFF;

      if (isHighSurrogate) {
        (buffer ??= StringBuffer(input.substring(0, i))).writeCharCode(0xFFFD);
        final hasPair = i + 1 < input.length &&
            input.codeUnitAt(i + 1) >= 0xDC00 &&
            input.codeUnitAt(i + 1) <= 0xDFFF;
        if (hasPair) i++; // consume its low surrogate too, valid pair or not
      } else if (isLowSurrogate) {
        // A lone low surrogate with no preceding high surrogate (a valid
        // pair's low half was already consumed above and never reaches
        // this branch).
        (buffer ??= StringBuffer(input.substring(0, i))).writeCharCode(0xFFFD);
      } else {
        buffer?.writeCharCode(code);
      }
    }
    return buffer?.toString() ?? input;
  }

  /// Saves editor content. Writes to a hidden sibling temp file first,
  /// then renames it over [path] — NOT a direct write. A direct
  /// `writeAsString` to the real path leaves a truncated/corrupted file
  /// behind if the process dies mid-write (app crash, or Android
  /// OOM-killing the process — a real possibility on the 3GB-RAM devices
  /// this app targets, not just a theoretical edge case). `File.rename`
  /// on the same filesystem is atomic on Android/Linux, so a crash at
  /// any point during this still leaves either the complete old file or
  /// the complete new one — never a half-written mix of both.
  Future<void> saveToPath(String path, String content) async {
    final file = File(path);
    await file.create(recursive: true);
    final dir = file.parent.path;
    final tempFile = File('$dir/.${file.uri.pathSegments.last}.gaxtmp');
    await tempFile.writeAsString(content, flush: true);
    await tempFile.rename(path);
  }

  /// Same atomic write as [saveToPath], for raw bytes rather than text —
  /// used when the source is already binary (e.g. a SAF copy-out), so it
  /// never has to round-trip through a String and risk mangling
  /// anything that isn't valid UTF-8.
  Future<void> saveBytesToPath(String path, Uint8List bytes) async {
    final file = File(path);
    await file.create(recursive: true);
    final dir = file.parent.path;
    final tempFile = File('$dir/.${file.uri.pathSegments.last}.gaxtmp');
    await tempFile.writeAsBytes(bytes, flush: true);
    await tempFile.rename(path);
  }

  Future<void> createFile(String dirPath, String fileName, {String content = ''}) async {
    final file = File('$dirPath/$fileName');
    if (await file.exists()) throw Exception('A file with that name already exists.');
    await file.create(recursive: true);
    if (content.isNotEmpty) await file.writeAsString(content);
  }

  Future<void> createFolder(String dirPath, String folderName) async {
    final dir = Directory('$dirPath/$folderName');
    if (await dir.exists()) throw Exception('A folder with that name already exists.');
    await dir.create(recursive: true);
  }

  Future<String> rename(String oldPath, bool isDirectory, String newName) async {
    final parent = oldPath.substring(0, oldPath.lastIndexOf('/'));
    final newPath = '$parent/$newName';
    if (isDirectory) {
      await Directory(oldPath).rename(newPath);
    } else {
      await File(oldPath).rename(newPath);
    }
    return newPath;
  }

  /// Counts every FILE (not folder) under [path], recursively — used only
  /// to give delete's progress callback a denominator (file *count* is
  /// the right unit there: deleting is dominated by per-file syscall
  /// overhead, not by file size). A lone file counts as 1.
  Future<int> _countFiles(String path) async {
    final entity = FileSystemEntity.typeSync(path);
    if (entity == FileSystemEntityType.file) return 1;
    if (entity != FileSystemEntityType.directory) return 0;
    var count = 0;
    await for (final child in Directory(path).list(recursive: true, followLinks: false)) {
      if (child is File) count++;
    }
    return count == 0 ? 1 : count; // an empty folder still counts as "one unit of work"
  }

  /// Total bytes under [path], recursively — copy/move progress is
  /// weighted by this instead of file *count*, since count alone lies
  /// badly the moment file sizes vary: 99 tiny files + 1 two-GB video
  /// would hit 99% almost instantly, then appear to hang while the
  /// video — which is actually most of the work — copies.
  Future<int> _totalBytes(String path) async {
    final entity = FileSystemEntity.typeSync(path);
    if (entity == FileSystemEntityType.file) return File(path).length();
    if (entity != FileSystemEntityType.directory) return 0;
    var total = 0;
    await for (final child in Directory(path).list(recursive: true, followLinks: false)) {
      if (child is File) total += await child.length();
    }
    return total == 0 ? 1 : total; // an empty folder still counts as "one unit of work"
  }

  /// Files this size or larger are copied via a chunked byte stream (with
  /// a progress tick per chunk) instead of one `File.copy()` call — below
  /// this, the whole-file copy is already near-instant, so streaming
  /// would only add syscall overhead for no visible benefit.
  static const _streamCopyThresholdBytes = 8 * 1024 * 1024; // 8 MB

  /// Deletes [path]. [onProgress] (0.0-1.0) is reported per-file for a
  /// folder, so a big delete can show real percentage instead of just
  /// spinning with no feedback. Pass [cancelToken] to let a batch caller
  /// stop a folder delete partway through (checked between files, not
  /// mid-file — a single file's own delete syscall is already atomic).
  Future<void> delete(String path, bool isDirectory, {void Function(double progress)? onProgress, CancellationToken? cancelToken}) async {
    if (!isDirectory) {
      await File(path).delete();
      onProgress?.call(1);
      return;
    }

    final total = await _countFiles(path);
    var done = 0;
    void tick() {
      done++;
      onProgress?.call((done / total).clamp(0.0, 1.0));
    }

    Future<void> deleteDir(Directory dir) async {
      final children = await dir.list(followLinks: false).toList();
      for (final child in children) {
        cancelToken?.throwIfCancelled();
        if (child is Directory) {
          await deleteDir(child);
        } else {
          await child.delete();
          tick();
        }
      }
      await dir.delete();
    }

    await deleteDir(Directory(path));
    onProgress?.call(1);
  }

  Future<void> copyEntry(
    String sourcePath,
    String destDir,
    bool isDirectory, {
    void Function(double progress)? onProgress,
    CancellationToken? cancelToken,
  }) async {
    final destPath = await _resolveCopyDestPath(sourcePath, destDir, isDirectory);
    await _performCopy(sourcePath, destPath, isDirectory, onProgress: onProgress, cancelToken: cancelToken);
  }

  Future<void> _performCopy(
    String sourcePath,
    String destPath,
    bool isDirectory, {
    void Function(double progress)? onProgress,
    CancellationToken? cancelToken,
  }) async {
    if (isDirectory) {
      final totalBytes = await _totalBytes(sourcePath);
      var copiedBytes = 0;
      await _copyDirectoryRecursive(
        sourcePath,
        destPath,
        cancelToken: cancelToken,
        onBytesCopied: (delta) {
          copiedBytes += delta;
          onProgress?.call((copiedBytes / totalBytes).clamp(0.0, 1.0));
        },
      );
    } else {
      final size = await File(sourcePath).length();
      var copied = 0;
      await _copyOneFile(
        File(sourcePath),
        destPath,
        onBytesDelta: (delta) {
          copied += delta;
          onProgress?.call((copied / size).clamp(0.0, 1.0));
        },
        cancelToken: cancelToken,
      );
    }
  }

  /// Copies a single file, streaming with periodic progress if it's
  /// large enough for that to matter (see [_streamCopyThresholdBytes]).
  /// Reports raw byte deltas (not a 0-1 fraction) so callers can
  /// accumulate across multiple files (a folder copy) or against a
  /// single file's own size, whichever applies. On cancellation
  /// mid-stream, deletes the partial destination file rather than
  /// leaving a silently-truncated copy behind.
  Future<void> _copyOneFile(File source, String destPath, {void Function(int bytesDelta)? onBytesDelta, CancellationToken? cancelToken}) async {
    final size = await source.length();
    if (size < _streamCopyThresholdBytes) {
      cancelToken?.throwIfCancelled();
      await source.copy(destPath);
      onBytesDelta?.call(size);
      return;
    }

    final dest = File(destPath);
    final sink = dest.openWrite();
    try {
      await for (final chunk in source.openRead()) {
        cancelToken?.throwIfCancelled();
        sink.add(chunk);
        onBytesDelta?.call(chunk.length);
      }
      await sink.flush();
      await sink.close();
    } catch (e) {
      await sink.close();
      if (await dest.exists()) await dest.delete();
      rethrow;
    }
  }

  /// Resolves where a copy/move should actually land. If nothing exists
  /// at the natural destination, uses it as-is. Otherwise — whether
  /// that's because the item is being pasted back into its own folder,
  /// or because a *different* file/folder there just happens to share
  /// the name — auto-appends "(copy)", then "(copy 2)", "(copy 3)"... so
  /// pasting can never silently overwrite or corrupt an existing file.
  Future<String> _resolveCopyDestPath(String sourcePath, String destDir, bool isDirectory) async {
    final name = sourcePath.split('/').last;
    final directPath = '$destDir/$name';
    if (!await File(directPath).exists() && !await Directory(directPath).exists()) {
      return directPath;
    }

    final hasExt = !isDirectory && name.contains('.') && !name.startsWith('.');
    final base = hasExt ? name.substring(0, name.lastIndexOf('.')) : name;
    final ext = hasExt ? name.substring(name.lastIndexOf('.')) : '';

    var candidate = '$destDir/$base (copy)$ext';
    var counter = 2;
    while (await File(candidate).exists() || await Directory(candidate).exists()) {
      candidate = '$destDir/$base (copy $counter)$ext';
      counter++;
    }
    return candidate;
  }

  Future<void> _copyDirectoryRecursive(String src, String dest, {void Function(int bytesDelta)? onBytesCopied, CancellationToken? cancelToken}) async {
    await Directory(dest).create(recursive: true);
    await for (final entity in Directory(src).list(followLinks: false)) {
      cancelToken?.throwIfCancelled();
      final name = entity.path.split('/').last;
      final newPath = '$dest/$name';
      if (entity is Directory) {
        await _copyDirectoryRecursive(entity.path, newPath, onBytesCopied: onBytesCopied, cancelToken: cancelToken);
      } else if (entity is File) {
        await _copyOneFile(
          entity,
          newPath,
          onBytesDelta: onBytesCopied,
          cancelToken: cancelToken,
        );
      }
    }
  }

  Future<void> moveEntry(
    String sourcePath,
    String destDir,
    bool isDirectory, {
    void Function(double progress)? onProgress,
    CancellationToken? cancelToken,
  }) async {
    final name = sourcePath.split('/').last;
    // Pasting a cut item back into the exact folder it came from is a
    // no-op — NOT "copy onto itself then delete the original", which is
    // what this used to do and could destroy the file entirely.
    if ('$destDir/$name' == sourcePath) {
      onProgress?.call(1);
      return;
    }
    final destPath = await _resolveCopyDestPath(sourcePath, destDir, isDirectory);
    // Copying is the slow part; treat it as the first 90% and the final
    // cleanup delete as the last 10%, so the bar doesn't sit at 100%
    // while the source is still being removed.
    await _performCopy(sourcePath, destPath, isDirectory, onProgress: (p) => onProgress?.call(p * 0.9), cancelToken: cancelToken);
    await delete(sourcePath, isDirectory, onProgress: (p) => onProgress?.call(0.9 + p * 0.1), cancelToken: cancelToken);
  }

  /// Recursively walks a git-repo folder and reads every trackable file as
  /// bytes, skipping [ignoreDirs] (defaults to [ignoredDirNames], but
  /// Settings can override this list). Used to build a GitHub push.
  Future<List<MapEntry<String, List<int>>>> collectFilesForPush(String rootPath, {List<String>? ignoreDirs}) async {
    final ignore = ignoreDirs ?? ignoredDirNames;
    final result = <MapEntry<String, List<int>>>[];

    Future<void> walk(Directory dir, String relBase) async {
      await for (final entity in dir.list(followLinks: false)) {
        final name = entity.path.split('/').last;
        if (entity is Directory) {
          if (ignore.contains(name)) continue;
          await walk(entity, '$relBase$name/');
        } else if (entity is File) {
          if (name == '.gaxide') continue;
          try {
            final bytes = await entity.readAsBytes();
            result.add(MapEntry('$relBase$name', bytes));
          } catch (_) {
            continue;
          }
        }
      }
    }

    await walk(Directory(rootPath), '');
    return result;
  }
}
