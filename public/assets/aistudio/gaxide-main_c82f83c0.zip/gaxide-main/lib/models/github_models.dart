/// Compact models for the GitHub tab — only the fields actually shown in
/// the UI, not a full mirror of GitHub's API responses.
class GithubUser {
  final String login;
  final String name;
  final String avatarUrl;
  final String htmlUrl;
  final int publicRepos;
  final int followers;

  const GithubUser({
    required this.login,
    required this.name,
    required this.avatarUrl,
    required this.htmlUrl,
    required this.publicRepos,
    required this.followers,
  });

  factory GithubUser.fromJson(Map<String, dynamic> json) => GithubUser(
        login: json['login'] as String? ?? '',
        name: json['name'] as String? ?? json['login'] as String? ?? '',
        avatarUrl: json['avatar_url'] as String? ?? '',
        htmlUrl: json['html_url'] as String? ?? '',
        publicRepos: json['public_repos'] as int? ?? 0,
        followers: json['followers'] as int? ?? 0,
      );
}

class GithubRepo {
  final String name;
  final String fullName;
  final String? description;
  final bool private;
  final String defaultBranch;
  final String updatedAt;
  final String htmlUrl;
  final int stargazersCount;

  const GithubRepo({
    required this.name,
    required this.fullName,
    required this.description,
    required this.private,
    required this.defaultBranch,
    required this.updatedAt,
    required this.htmlUrl,
    required this.stargazersCount,
  });

  String get owner => fullName.contains('/') ? fullName.split('/').first : '';

  factory GithubRepo.fromJson(Map<String, dynamic> json) => GithubRepo(
        name: json['name'] as String? ?? '',
        fullName: json['full_name'] as String? ?? '',
        description: json['description'] as String?,
        private: json['private'] as bool? ?? false,
        defaultBranch: json['default_branch'] as String? ?? 'main',
        updatedAt: json['updated_at'] as String? ?? '',
        htmlUrl: json['html_url'] as String? ?? '',
        stargazersCount: json['stargazers_count'] as int? ?? 0,
      );
}

class GithubCommit {
  final String sha;
  final String message;
  final String authorName;
  final String date;
  final String htmlUrl;

  const GithubCommit({
    required this.sha,
    required this.message,
    required this.authorName,
    required this.date,
    required this.htmlUrl,
  });

  factory GithubCommit.fromJson(Map<String, dynamic> json) {
    final commit = json['commit'] as Map<String, dynamic>? ?? {};
    final author = commit['author'] as Map<String, dynamic>? ?? {};
    return GithubCommit(
      sha: (json['sha'] as String? ?? '').substring(0, (json['sha'] as String? ?? '').length.clamp(0, 7)),
      message: (commit['message'] as String? ?? '').split('\n').first,
      authorName: author['name'] as String? ?? 'Unknown',
      date: author['date'] as String? ?? '',
      htmlUrl: json['html_url'] as String? ?? '',
    );
  }
}

class GithubActionRun {
  final String name;
  final String status; // queued, in_progress, completed
  final String? conclusion; // success, failure, cancelled, null if not completed
  final String htmlUrl;
  final String createdAt;
  final String branch;

  const GithubActionRun({
    required this.name,
    required this.status,
    required this.conclusion,
    required this.htmlUrl,
    required this.createdAt,
    required this.branch,
  });

  factory GithubActionRun.fromJson(Map<String, dynamic> json) => GithubActionRun(
        name: json['name'] as String? ?? json['display_title'] as String? ?? 'Workflow run',
        status: json['status'] as String? ?? 'unknown',
        conclusion: json['conclusion'] as String?,
        htmlUrl: json['html_url'] as String? ?? '',
        createdAt: json['created_at'] as String? ?? '',
        branch: json['head_branch'] as String? ?? '',
      );
}

class GithubRelease {
  final String tagName;
  final String name;
  final String publishedAt;
  final String htmlUrl;
  final bool prerelease;

  const GithubRelease({
    required this.tagName,
    required this.name,
    required this.publishedAt,
    required this.htmlUrl,
    required this.prerelease,
  });

  factory GithubRelease.fromJson(Map<String, dynamic> json) => GithubRelease(
        tagName: json['tag_name'] as String? ?? '',
        name: (json['name'] as String?)?.isNotEmpty == true ? json['name'] as String : (json['tag_name'] as String? ?? ''),
        publishedAt: json['published_at'] as String? ?? '',
        htmlUrl: json['html_url'] as String? ?? '',
        prerelease: json['prerelease'] as bool? ?? false,
      );
}
