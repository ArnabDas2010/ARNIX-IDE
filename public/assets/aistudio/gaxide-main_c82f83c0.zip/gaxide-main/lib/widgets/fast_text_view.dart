import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/prefs_service.dart';
import '../services/theme_controller.dart';

/// Read-only, line-numbered view of [content] that renders instantly
/// regardless of file size — each line is only built when it actually
/// scrolls into view (standard ListView.builder virtualization), unlike
/// a single big TextField/TextEditingController, which has to lay out
/// the ENTIRE string just to display any of it. Long lines soft-wrap
/// rather than scroll horizontally, trading a little visual tidiness
/// for not needing a second, synchronized scroll axis in a view whose
/// whole purpose is "show this fast, right now".
class FastTextView extends StatefulWidget {
  final String content;

  const FastTextView({super.key, required this.content});

  @override
  State<FastTextView> createState() => _FastTextViewState();
}

class _FastTextViewState extends State<FastTextView> {
  late final List<String> _lines = widget.content.split('\n');
  double _fontSize = 14;

  @override
  void initState() {
    super.initState();
    PrefsService().loadFontSize().then((size) {
      if (mounted) setState(() => _fontSize = size);
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final fontFamily = GoogleFonts.getFont(ThemeController.instance.editorFont).fontFamily;
    final gutterWidth = (_lines.length.toString().length * _fontSize * 0.65) + 16;

    return ListView.builder(
      // A little padding at each end so the first/last line isn't flush
      // against the app bar / bottom edge.
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _lines.length,
      itemBuilder: (context, i) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: gutterWidth,
                child: Text(
                  '${i + 1}',
                  textAlign: TextAlign.right,
                  style: TextStyle(fontFamily: fontFamily, fontSize: _fontSize * 0.8, color: scheme.onSurfaceVariant.withOpacity(0.6)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _lines[i],
                  style: TextStyle(fontFamily: fontFamily, fontSize: _fontSize, height: 1.4),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
