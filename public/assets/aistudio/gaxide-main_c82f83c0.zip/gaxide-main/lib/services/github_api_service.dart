import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/github_models.dart';

class ApiResult<T> {
  final bool success;
  final T? data;
  final String? error;
  const ApiResult.ok(this.data)
      : success = true,
        error = null;
  const ApiResult.fail(this.error)
      : success = false,
        data = null;
}

/// Everything the GitHub tab needs, beyond the blob/tree/commit push
/// mechanics already in [GithubService] — profile, repo list, create/
/// delete, and a repo's recent commits/Actions runs/releases. Kept as a
/// separate service since it's a distinct concern (browsing GitHub, not
/// pushing to it), even though both ultimately call the same REST API.
class GithubApiService {
  static const _base = 'https://api.github.com';

  // A hung request (bad Wi-Fi, captive portal) used to wait forever with
  // no feedback — every request below now gives up after this and
  // surfaces a normal TimeoutException through the existing catch block.
  static const _timeout = Duration(seconds: 15);

  Map<String, String> _headers(String token) => {
        'Authorization': 'token $token',
        'Accept': 'application/vnd.github.v3+json',
      };

  Future<ApiResult<GithubUser>> fetchUser(String token) async {
    try {
      final res = await http.get(Uri.parse('$_base/user'), headers: _headers(token)).timeout(_timeout);
      if (res.statusCode != 200) return ApiResult.fail('GitHub rejected the token [${res.statusCode}]');
      return ApiResult.ok(GithubUser.fromJson(jsonDecode(res.body) as Map<String, dynamic>));
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  /// Fetches every repo the token can see, paging through GitHub's
  /// 50-per-page results — previously capped at a single page, so an
  /// account with 50+ repos silently only ever showed the newest 50
  /// with no hint that anything was missing. Capped at 20 pages (1000
  /// repos) as a sane upper bound against a runaway loop.
  Future<ApiResult<List<GithubRepo>>> fetchRepos(String token) async {
    try {
      final all = <GithubRepo>[];
      for (var page = 1; page <= 20; page++) {
        final res = await http
            .get(
              Uri.parse('$_base/user/repos?sort=updated&per_page=50&page=$page&affiliation=owner,collaborator'),
              headers: _headers(token),
            )
            .timeout(_timeout);
        if (res.statusCode != 200) return ApiResult.fail('Could not load repos [${res.statusCode}]');
        final list = jsonDecode(res.body) as List<dynamic>;
        all.addAll(list.map((e) => GithubRepo.fromJson(e as Map<String, dynamic>)));
        if (list.length < 50) break; // last page
      }
      return ApiResult.ok(all);
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  Future<ApiResult<GithubRepo>> createRepo(
    String token, {
    required String name,
    String description = '',
    bool private = true,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$_base/user/repos'),
        headers: {..._headers(token), 'Content-Type': 'application/json'},
        body: jsonEncode({'name': name, 'description': description, 'private': private, 'auto_init': true}),
      ).timeout(_timeout);
      if (res.statusCode == 201) {
        return ApiResult.ok(GithubRepo.fromJson(jsonDecode(res.body) as Map<String, dynamic>));
      }
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      return ApiResult.fail(body['message'] as String? ?? 'Failed [${res.statusCode}]');
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  Future<ApiResult<void>> deleteRepo(String token, String owner, String repo) async {
    try {
      final res = await http.delete(Uri.parse('$_base/repos/$owner/$repo'), headers: _headers(token)).timeout(_timeout);
      if (res.statusCode == 204) return const ApiResult.ok(null);
      if (res.statusCode == 403) {
        return const ApiResult.fail('Token is missing the "delete_repo" permission.');
      }
      return ApiResult.fail('Failed [${res.statusCode}]');
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  Future<ApiResult<List<GithubCommit>>> fetchCommits(String token, String owner, String repo) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/repos/$owner/$repo/commits?per_page=10'),
        headers: _headers(token),
      ).timeout(_timeout);
      if (res.statusCode != 200) return ApiResult.fail('Could not load commits [${res.statusCode}]');
      final list = jsonDecode(res.body) as List<dynamic>;
      return ApiResult.ok(list.map((e) => GithubCommit.fromJson(e as Map<String, dynamic>)).toList());
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  Future<ApiResult<List<GithubActionRun>>> fetchActionRuns(String token, String owner, String repo) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/repos/$owner/$repo/actions/runs?per_page=10'),
        headers: _headers(token),
      ).timeout(_timeout);
      if (res.statusCode != 200) return ApiResult.fail('Could not load Actions runs [${res.statusCode}]');
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final list = data['workflow_runs'] as List<dynamic>? ?? [];
      return ApiResult.ok(list.map((e) => GithubActionRun.fromJson(e as Map<String, dynamic>)).toList());
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }

  Future<ApiResult<List<GithubRelease>>> fetchReleases(String token, String owner, String repo) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/repos/$owner/$repo/releases?per_page=10'),
        headers: _headers(token),
      ).timeout(_timeout);
      if (res.statusCode != 200) return ApiResult.fail('Could not load releases [${res.statusCode}]');
      final list = jsonDecode(res.body) as List<dynamic>;
      return ApiResult.ok(list.map((e) => GithubRelease.fromJson(e as Map<String, dynamic>)).toList());
    } catch (e) {
      return ApiResult.fail('$e');
    }
  }
}
