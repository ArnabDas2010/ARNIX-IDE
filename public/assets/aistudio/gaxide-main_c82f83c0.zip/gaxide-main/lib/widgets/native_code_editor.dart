import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Native (Kotlin EditText) large-file editor — see
/// NativeCodeEditorView.kt for the full scope/limitations of this v1
/// (no syntax highlighting, no app-level undo/redo, fixed monospace
/// font). Used only for files above the size where Flutter's own
/// TextField becomes too slow to render (see FastTextView's "Edit
/// Anyway" path in editor_screen.dart) — normal files keep using the
/// existing Flutter-based CodeEditorView, which is already fast.
///
/// Call [getText] (via a GlobalKey<NativeCodeEditorState>) when you
/// actually need the current content — e.g. on Save. There is
/// deliberately no live/streaming text sync: marshaling a 100KB+
/// string across the platform channel on every keystroke would
/// reintroduce the exact cost this widget exists to avoid.
class NativeCodeEditor extends StatefulWidget {
  final String initialText;
  final double fontSize;
  final bool readOnly;

  const NativeCodeEditor({super.key, required this.initialText, required this.fontSize, this.readOnly = false});

  @override
  State<NativeCodeEditor> createState() => NativeCodeEditorState();
}

class NativeCodeEditorState extends State<NativeCodeEditor> {
  MethodChannel? _channel;

  void _onPlatformViewCreated(int id) {
    _channel = MethodChannel('com.gax.ide/native_editor_$id');
  }

  /// Current content of the native editor. Falls back to the original
  /// text if the platform view hasn't finished creating yet (shouldn't
  /// normally happen — Save is only reachable once the screen, and so
  /// this view, has been visible for a while — but better a safe
  /// fallback than a crash).
  Future<String> getText() async {
    final channel = _channel;
    if (channel == null) return widget.initialText;
    try {
      final result = await channel.invokeMethod<String>('getText');
      return result ?? widget.initialText;
    } on PlatformException {
      return widget.initialText;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return AndroidView(
      viewType: 'com.gax.ide/native_editor',
      creationParams: {
        'text': widget.initialText,
        'fontSize': widget.fontSize,
        'readOnly': widget.readOnly,
        'isDark': isDark,
      },
      creationParamsCodec: const StandardMessageCodec(),
      onPlatformViewCreated: _onPlatformViewCreated,
    );
  }
}
