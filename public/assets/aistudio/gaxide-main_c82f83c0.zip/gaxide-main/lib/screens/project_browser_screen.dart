import 'package:flutter/material.dart';
import '../services/clipboard_controller.dart';
import '../widgets/file_browser_view.dart';

/// Hosts one [FileBrowserView] as a standalone pushed screen — used by
/// the Workspace tab to open a pinned project. All the actual browsing
/// logic (search, sort, multi-select, FAB actions) lives in
/// FileBrowserView already; this is just the Scaffold/AppBar chrome
/// around it, mirroring how the Files tab wires the same widget.
class ProjectBrowserScreen extends StatefulWidget {
  final String folderPath;
  final String title;

  const ProjectBrowserScreen({super.key, required this.folderPath, required this.title});

  @override
  State<ProjectBrowserScreen> createState() => _ProjectBrowserScreenState();
}

class _ProjectBrowserScreenState extends State<ProjectBrowserScreen> {
  final _clipboard = ClipboardController();
  final _browserKey = GlobalKey<FileBrowserViewState>();

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _browserKey.currentState?.canPopFreely() ?? true,
      onPopInvoked: (didPop) {
        if (didPop) return;
        _browserKey.currentState?.handleBackPress();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(
              tooltip: 'Search',
              icon: const Icon(Icons.search_rounded),
              onPressed: () => _browserKey.currentState?.toggleSearch(),
            ),
            IconButton(
              tooltip: 'Home',
              icon: const Icon(Icons.home_rounded),
              onPressed: () => _browserKey.currentState?.goHome(),
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded),
              onSelected: (value) {
                switch (value) {
                  case 'sort':
                    _browserKey.currentState?.showSortSheet();
                    break;
                  case 'select':
                    _browserKey.currentState?.enterSelectionMode();
                    break;
                }
              },
              itemBuilder: (ctx) => const [
                PopupMenuItem(value: 'sort', child: Text('Sort by...')),
                PopupMenuItem(value: 'select', child: Text('Select Files')),
              ],
            ),
          ],
        ),
        body: FileBrowserView(
          key: _browserKey,
          rootPath: widget.folderPath,
          tabLabel: widget.title,
          clipboard: _clipboard,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _browserKey.currentState?.showCreateSheet(),
          child: const Icon(Icons.add_rounded),
        ),
      ),
    );
  }
}
