/// A single entry inside a SAF (Storage Access Framework) tree — the
/// content:// URI equivalent of FileEntry, used for folders a normal
/// java.io.File path can't reach (see SafService).
class SafDocument {
  final String uri;
  final String name;
  final bool isDirectory;
  final int size;
  final int lastModified;

  const SafDocument({
    required this.uri,
    required this.name,
    required this.isDirectory,
    required this.size,
    required this.lastModified,
  });

  factory SafDocument.fromMap(Map<Object?, Object?> map) {
    return SafDocument(
      uri: map['uri'] as String,
      name: map['name'] as String,
      isDirectory: map['isDirectory'] as bool,
      size: (map['size'] as num?)?.toInt() ?? 0,
      lastModified: (map['lastModified'] as num?)?.toInt() ?? 0,
    );
  }
}

/// A previously-granted SAF tree the user can reopen without going
/// through the system picker again.
class SafTree {
  final String uri;
  final String name;
  const SafTree({required this.uri, required this.name});

  factory SafTree.fromMap(Map<Object?, Object?> map) {
    return SafTree(uri: map['uri'] as String, name: map['name'] as String);
  }
}
