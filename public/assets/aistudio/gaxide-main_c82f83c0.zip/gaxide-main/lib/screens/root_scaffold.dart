import 'package:flutter/material.dart';
import 'file_manager_screen.dart';
import 'github_screen.dart';
import 'settings_screen.dart';
import 'workspace_screen.dart';

class RootScaffold extends StatefulWidget {
  const RootScaffold({super.key});

  @override
  State<RootScaffold> createState() => _RootScaffoldState();
}

class _RootScaffoldState extends State<RootScaffold> {
  int _index = 0;

  final _workspaceKey = GlobalKey<WorkspaceScreenState>();
  final _filesKey = GlobalKey<FilesTabScreenState>();
  final _githubKey = GlobalKey<GithubScreenState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          WorkspaceScreen(key: _workspaceKey),
          FilesTabScreen(key: _filesKey),
          GithubScreen(key: _githubKey),
          const SettingsScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) {
          setState(() => _index = i);
          // IndexedStack children only ever run initState() once, so
          // each tab refreshes its own data right when it's selected
          // instead — cheap, and correctly picks up anything changed
          // elsewhere (e.g. a Settings toggle, or a push that just
          // happened on a Workspace project).
          switch (i) {
            case 0:
              _workspaceKey.currentState?.refresh();
              break;
            case 1:
              _filesKey.currentState?.reloadAfterSettingsChange();
              break;
            case 2:
              _githubKey.currentState?.ensureLoaded();
              break;
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Workspace'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Files'),
          NavigationDestination(icon: Icon(Icons.cloud_outlined), selectedIcon: Icon(Icons.cloud_rounded), label: 'GitHub'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
    );
  }
}
