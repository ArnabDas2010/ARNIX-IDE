import 'package:flutter/material.dart';
import '../models/github_models.dart';
import '../services/github_api_service.dart';
import '../services/prefs_service.dart';
import 'github_repo_detail_screen.dart';
import '../widgets/message_dialog.dart';
import '../widgets/progress_dialog.dart';

/// The GitHub bottom-nav tab — profile + repos, with create/delete/
/// refresh and a tap-through to each repo's recent commits/Actions/
/// releases. Deliberately NOT a full GitHub client — no issues, PRs, or
/// code browsing, just the things a developer checks often.
///
/// Lazy-loaded: [RootScaffold] only builds this tab's data fetch once
/// it's actually selected, not before — see [ensureLoaded].
class GithubScreen extends StatefulWidget {
  const GithubScreen({super.key});

  @override
  State<GithubScreen> createState() => GithubScreenState();
}

class GithubScreenState extends State<GithubScreen> with AutomaticKeepAliveClientMixin {
  final _prefsService = PrefsService();
  final _api = GithubApiService();

  bool _loading = true;
  String? _error;
  String _token = '';
  GithubUser? _user;
  List<GithubRepo> _repos = [];

  @override
  bool get wantKeepAlive => true;

  /// Called by RootScaffold right when this tab is first selected — the
  /// actual lazy-load trigger, since initState alone would fire even for
  /// an offstage IndexedStack child built up front. Skips re-fetching
  /// once a profile has actually loaded (so switching tabs back and
  /// forth doesn't re-hit the API every time), but keeps retrying on
  /// each visit until then — e.g. if the token was only just added in
  /// Settings after this tab was already opened once.
  void ensureLoaded() {
    if (_user != null) return;
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final config = await _prefsService.loadConfig();
    _token = config.token;
    if (_token.isEmpty) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    final userResult = await _api.fetchUser(_token);
    if (!userResult.success) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = userResult.error;
        });
      }
      return;
    }

    final reposResult = await _api.fetchRepos(_token);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _user = userResult.data;
      _repos = reposResult.data ?? [];
      _error = reposResult.success ? null : reposResult.error;
    });
  }

  Future<void> _refresh() => _load();

  Future<void> _createRepo() async {
    final nameController = TextEditingController();
    final descController = TextEditingController();
    bool isPrivate = true;

    final created = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Create Repository'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(controller: nameController, autofocus: true, decoration: const InputDecoration(labelText: 'Repository name')),
              const SizedBox(height: 10),
              TextField(controller: descController, decoration: const InputDecoration(labelText: 'Description (optional)')),
              const SizedBox(height: 6),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Private'),
                value: isPrivate,
                onChanged: (v) => setDialogState(() => isPrivate = v),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create')),
          ],
        ),
      ),
    );

    if (created != true || nameController.text.trim().isEmpty) return;

    final busy = showBusyDialog(context, message: 'Creating repository...');
    final result = await _api.createRepo(
      _token,
      name: nameController.text.trim(),
      description: descController.text.trim(),
      private: isPrivate,
    );
    busy.close();
    if (!mounted) return;
    showMessageDialog(
      context,
      result.success ? 'Repository created' : '${result.error}',
      isError: !result.success,
    );
    if (result.success) _load();
  }

  Future<void> _deleteRepo(GithubRepo repo) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Repository?'),
        content: Text('"${repo.fullName}" will be permanently deleted from GitHub. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final busy = showBusyDialog(context, message: 'Deleting repository...');
    final result = await _api.deleteRepo(_token, repo.owner, repo.name);
    busy.close();
    if (!mounted) return;
    showMessageDialog(
      context,
      result.success ? 'Repository deleted' : '${result.error}',
      isError: !result.success,
    );
    if (result.success) _load();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('GitHub'),
        actions: [
          if (_token.isNotEmpty)
            IconButton(tooltip: 'Refresh', icon: const Icon(Icons.refresh_rounded), onPressed: _refresh),
        ],
      ),
      floatingActionButton: _token.isEmpty
          ? null
          : FloatingActionButton(onPressed: _createRepo, child: const Icon(Icons.add_rounded)),
      body: SafeArea(child: _buildBody(scheme)),
    );
  }

  Widget _buildBody(ColorScheme scheme) {
    if (_token.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.key_off_rounded, size: 44, color: scheme.onSurfaceVariant),
              const SizedBox(height: 12),
              const Text('No GitHub Token set up yet.', textAlign: TextAlign.center),
              const SizedBox(height: 6),
              Text(
                'Add a Personal Access Token in Settings to see your profile and repos.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant.withOpacity(0.8)),
              ),
            ],
          ),
        ),
      );
    }

    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_user == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded, size: 44, color: scheme.onSurfaceVariant),
              const SizedBox(height: 12),
              Text('⚠️ ${_error ?? 'Could not load your GitHub profile.'}', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _refresh, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _profileCard(scheme, _user!),
          const SizedBox(height: 18),
          Row(
            children: [
              const Text('Repositories', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(width: 8),
              Text('(${_repos.length})', style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
            ],
          ),
          const SizedBox(height: 8),
          if (_error != null) ...[
            Text('⚠️ $_error', style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            const SizedBox(height: 8),
          ],
          if (_repos.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Text('No repositories yet — tap + to create one.',
                  style: TextStyle(color: scheme.onSurfaceVariant)),
            )
          else
            ..._repos.map((r) => _repoCard(scheme, r)),
        ],
      ),
    );
  }

  Widget _profileCard(ColorScheme scheme, GithubUser user) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [scheme.surfaceContainerHigh.withOpacity(0.85), scheme.surfaceContainer.withOpacity(0.55)],
        ),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: scheme.surfaceContainerHighest,
            backgroundImage: user.avatarUrl.isNotEmpty ? NetworkImage(user.avatarUrl) : null,
            child: user.avatarUrl.isEmpty ? const Icon(Icons.person_rounded, size: 30) : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text('@${user.login}', style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 13)),
                const SizedBox(height: 6),
                Text(
                  '${user.publicRepos} repos · ${user.followers} followers',
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant.withOpacity(0.8)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _repoCard(ColorScheme scheme, GithubRepo repo) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: scheme.surfaceContainerHigh.withOpacity(0.6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Icon(
          repo.private ? Icons.lock_outline_rounded : Icons.public_rounded,
          color: repo.private ? Colors.amberAccent : Colors.greenAccent,
        ),
        title: Text(repo.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          repo.description?.isNotEmpty == true ? repo.description! : repo.defaultBranch,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline_rounded, size: 20, color: Colors.redAccent),
          onPressed: () => _deleteRepo(repo),
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => GithubRepoDetailScreen(token: _token, repo: repo)),
        ),
      ),
    );
  }
}
