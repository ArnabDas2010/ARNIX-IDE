import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';

import '../models/file_entry.dart';
import '../models/sort_mode.dart';
import '../services/archive_service.dart';
import '../services/clipboard_controller.dart';
import '../services/file_service.dart';
import '../services/prefs_service.dart';
import '../services/saf_service.dart';
import '../services/template_service.dart';
import '../utils/cancellation_token.dart';
import '../widgets/file_list_tile.dart';
import '../widgets/file_info_dialog.dart';
import '../widgets/repo_push_dialog.dart';
import '../widgets/progress_dialog.dart';
import '../widgets/message_dialog.dart';
import '../screens/editor_screen.dart';
import '../screens/image_viewer_screen.dart';
import '../screens/archive_viewer_screen.dart';
import '../screens/saf_browser_screen.dart';

/// One storage tab's worth of file browsing — its own root, its own
/// navigation/search/sort/selection state. The parent (FilesTabScreen or
/// ProjectBrowserScreen)
/// drives search/sort/select/create/back-navigation through this State's
/// public methods via a GlobalKey, since the shared app bar/FAB live above
/// both tabs.
class FileBrowserView extends StatefulWidget {
  final String rootPath;
  final String tabLabel;
  final ClipboardController clipboard;
  final VoidCallback? onNavigationChanged;
  final bool isWorkplaceTab;

  const FileBrowserView({
    super.key,
    required this.rootPath,
    required this.tabLabel,
    required this.clipboard,
    this.onNavigationChanged,
    this.isWorkplaceTab = false,
  });

  @override
  State<FileBrowserView> createState() => FileBrowserViewState();
}

class FileBrowserViewState extends State<FileBrowserView> {
  final _fileService = FileService();
  final _archiveService = ArchiveService();
  final _prefsService = PrefsService();
  final _saf = SafService();
  final _templateService = TemplateService();

  // Customizable in Settings — defaults to 100KB, loaded in _bootstrap()
  // and refreshed by reloadPreferences().
  int _largeFileWarningBytes = 100 * 1024;

  late String _currentPath = widget.rootPath;
  List<FileEntry> _allEntries = [];
  bool _loading = true;
  bool _permissionDenied = false;

  bool _isSearching = false;
  String _searchQuery = '';
  final _searchController = TextEditingController();

  SortMode _sortMode = SortMode.nameAsc;
  bool _showHidden = false;
  bool _confirmBeforeDelete = true;

  bool _selectionModeActive = false;
  final Set<String> _selectedPaths = {};

  // Workplace-only state: showing the pinned-shortcuts list vs. having
  // drilled into one shortcut's real folder contents.
  bool _atShortcutsList = false;
  String? _activeShortcutRoot;
  List<FileEntry> _shortcutEntries = [];

  @override
  void initState() {
    super.initState();
    widget.clipboard.addListener(_onClipboardChanged);
    _bootstrap();
  }

  @override
  void didUpdateWidget(covariant FileBrowserView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.rootPath != widget.rootPath) {
      _currentPath = widget.rootPath;
      _loadDirectory(widget.rootPath);
    }
  }

  @override
  void dispose() {
    widget.clipboard.removeListener(_onClipboardChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onClipboardChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _bootstrap() async {
    final prefs = await _prefsService.loadFileManagerPrefs();
    _sortMode = SortMode.values[prefs.defaultSortIndex];
    _showHidden = prefs.showHiddenFiles;
    _confirmBeforeDelete = prefs.confirmBeforeDelete;

    final perfPrefs = await _prefsService.loadPerformancePrefs();
    _largeFileWarningBytes = perfPrefs.largeFileWarningKb * 1024;

    final granted = await _fileService.ensureStoragePermission();
    if (!granted) {
      if (mounted) {
        setState(() {
          _permissionDenied = true;
          _loading = false;
        });
      }
      return;
    }

    if (widget.isWorkplaceTab) {
      await _seedSamplesShortcutIfNeeded();
      await _loadShortcuts();
      if (mounted) {
        setState(() {
          _atShortcutsList = true;
          _loading = false;
        });
      }
      return;
    }

    await _loadDirectory(_currentPath);
  }

  /// Seeds a default "Samples" Workplace shortcut pointing at a real,
  /// on-disk copy of the bundled templates — once, ever. If the user
  /// removes it later it stays gone (never re-added); the templates
  /// themselves stay available regardless via "New File from Template",
  /// since that reads straight from the app's bundled assets, not this
  /// copied folder.
  Future<void> _seedSamplesShortcutIfNeeded() async {
    if (await _prefsService.hasSeededSamplesShortcut()) return;
    try {
      final samplesPath = await _templateService.ensureSamplesFolderOnDisk();
      final shortcuts = await _prefsService.loadWorkplaceShortcuts();
      if (!shortcuts.contains(samplesPath)) {
        shortcuts.add(samplesPath);
        await _prefsService.saveWorkplaceShortcuts(shortcuts);
      }
    } catch (_) {
      // Non-fatal — templates remain usable via "New File from Template" either way.
    }
    await _prefsService.setSeededSamplesShortcut();
  }

  /// Reads the pinned shortcut paths and builds display entries for them.
  /// Shortcuts whose real folder no longer exists (deleted/moved) are
  /// silently pruned from the saved list.
  Future<void> _loadShortcuts() async {
    final paths = await _prefsService.loadWorkplaceShortcuts();
    final entries = <FileEntry>[];
    final stillValid = <String>[];

    for (final path in paths) {
      final dir = Directory(path);
      if (await dir.exists()) {
        try {
          final stat = await dir.stat();
          final isGit = await Directory('$path/.git').exists();
          entries.add(FileEntry(
            name: path.split('/').last,
            path: path,
            isDirectory: true,
            sizeBytes: 0,
            modified: stat.modified,
            isGitRepo: isGit,
          ));
          stillValid.add(path);
        } catch (_) {
          continue;
        }
      }
    }

    if (stillValid.length != paths.length) {
      await _prefsService.saveWorkplaceShortcuts(stillValid);
    }
    if (mounted) setState(() => _shortcutEntries = entries);
  }

  /// Called by the parent when this tab becomes active, so newly-added
  /// shortcuts (pinned from another tab) show up immediately.
  Future<void> reloadShortcuts() async {
    if (!widget.isWorkplaceTab) return;
    await _loadShortcuts();
  }

  Future<void> _openShortcut(FileEntry entry) async {
    setState(() {
      _atShortcutsList = false;
      _activeShortcutRoot = entry.path;
    });
    await _loadDirectory(entry.path);
  }

  Future<void> _addToWorkplace(FileEntry entry) async {
    final current = await _prefsService.loadWorkplaceShortcuts();
    if (!current.contains(entry.path)) {
      current.add(entry.path);
      await _prefsService.saveWorkplaceShortcuts(current);
    }
    if (mounted) {
      showMessageDialog(context, 'Added "${entry.name}" to Workplace');
    }
  }

  /// Renames the actual on-disk folder a Workplace shortcut points at, and
  /// keeps the pinned shortcut path in sync afterward — unlike the normal
  /// _renameEntry (built for regular directory browsing), which has no
  /// concept of a shortcut list to update.
  Future<void> _renameShortcut(FileEntry entry) async {
    final controller = TextEditingController(text: entry.name);
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Rename')),
        ],
      ),
    );
    if (result != true || controller.text.trim().isEmpty) return;

    try {
      final newPath = await _fileService.rename(entry.path, true, controller.text.trim());
      final shortcuts = await _prefsService.loadWorkplaceShortcuts();
      final idx = shortcuts.indexOf(entry.path);
      if (idx != -1) {
        shortcuts[idx] = newPath;
        await _prefsService.saveWorkplaceShortcuts(shortcuts);
      }
      await _loadShortcuts();
    } catch (e) {
      if (mounted) showMessageDialog(context, '❌ $e', isError: true);
    }
  }

  Future<void> _removeFromWorkplace(String path) async {
    final current = await _prefsService.loadWorkplaceShortcuts();
    current.remove(path);
    await _prefsService.saveWorkplaceShortcuts(current);
    await _loadShortcuts();
  }

  /// Re-reads persisted behavior settings (called by the parent after the
  /// user returns from the Settings screen).
  Future<void> reloadPreferences() async {
    final prefs = await _prefsService.loadFileManagerPrefs();
    final perfPrefs = await _prefsService.loadPerformancePrefs();
    if (!mounted) return;
    setState(() {
      _sortMode = SortMode.values[prefs.defaultSortIndex];
      _showHidden = prefs.showHiddenFiles;
      _confirmBeforeDelete = prefs.confirmBeforeDelete;
      _largeFileWarningBytes = perfPrefs.largeFileWarningKb * 1024;
    });
    if (!(widget.isWorkplaceTab && _atShortcutsList)) {
      _loadDirectory(_currentPath);
    }
  }

  /// Android/data and Android/obb throw a permission error from plain
  /// dart:io navigation no matter what (see SAF_ANDROID_DATA note in
  /// MainActivity.kt) — rather than showing that error and stopping,
  /// redirect into the SAF-backed browser automatically. First time,
  /// this means the system picker pops up right where the user expected
  /// the folder to just open (exactly how ZArchiver behaves); every
  /// time after, a persisted grant already exists so it opens directly
  /// with no picker at all.
  bool _isRestrictedAndroidPath(String path) {
    return path == '${widget.rootPath}/Android/data' || path == '${widget.rootPath}/Android/obb';
  }

  Future<void> _openRestrictedAndroidPath(String path) async {
    final hint = path.endsWith('/data') ? 'Android/data' : 'Android/obb';
    final persisted = await _saf.listPersistedTrees();
    final existing = persisted.where((t) => t.name == hint);
    if (existing.isNotEmpty) {
      if (mounted) {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => SafBrowserScreen(treeUri: existing.first.uri, currentUri: existing.first.uri, title: hint)),
        );
      }
      return;
    }

    String? uri;
    try {
      uri = await _saf.pickTree(hint: hint);
    } catch (e) {
      if (mounted) showMessageDialog(context, '$e', isError: true);
      return;
    }
    // User backed out of the system picker — quietly stay right where
    // they were in the normal file list, not an error.
    if (uri == null || !mounted) return;
    final grantedUri = uri;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SafBrowserScreen(treeUri: grantedUri, currentUri: grantedUri, title: hint)),
    );
  }

  Future<void> _loadDirectory(String path) async {
    if (_isRestrictedAndroidPath(path)) {
      await _openRestrictedAndroidPath(path);
      return;
    }
    setState(() => _loading = true);
    try {
      final entries = await _fileService.listDirectory(path, showHidden: _showHidden);
      if (!mounted) return;
      setState(() {
        _currentPath = path;
        _allEntries = entries;
        _loading = false;
        _permissionDenied = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showMessageDialog(context, 'Cannot open this folder: $e', isError: true);
    }
    widget.onNavigationChanged?.call();
  }

  bool get _atRoot => widget.isWorkplaceTab ? _atShortcutsList : _currentPath == widget.rootPath;
  String get _folderTitle => _atRoot ? widget.tabLabel : _currentPath.split('/').last;

  List<FileEntry> get _visibleEntries {
    var list = _allEntries;
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list.where((e) => e.name.toLowerCase().contains(q)).toList();
    }
    final sorted = [...list];
    sorted.sort((a, b) {
      if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
      switch (_sortMode) {
        case SortMode.nameAsc:
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case SortMode.nameDesc:
          return b.name.toLowerCase().compareTo(a.name.toLowerCase());
        case SortMode.dateNewest:
          return b.modified.compareTo(a.modified);
        case SortMode.dateOldest:
          return a.modified.compareTo(b.modified);
        case SortMode.sizeLargest:
          return b.sizeBytes.compareTo(a.sizeBytes);
        case SortMode.sizeSmallest:
          return a.sizeBytes.compareTo(b.sizeBytes);
      }
    });
    return sorted;
  }

  void _navigateUp() {
    if (widget.isWorkplaceTab && _currentPath == _activeShortcutRoot) {
      setState(() {
        _atShortcutsList = true;
        _activeShortcutRoot = null;
      });
      widget.onNavigationChanged?.call();
      return;
    }
    if (_atRoot) return;
    final segments = _currentPath.split('/')..removeLast();
    _loadDirectory(segments.join('/'));
  }

  // ---------------- Public API — driven by the parent's shared app bar/FAB ----------------

  bool canPopFreely() => _atRoot && !_isSearching && !_selectionModeActive;

  void handleBackPress() {
    if (_selectionModeActive) {
      setState(() {
        _selectionModeActive = false;
        _selectedPaths.clear();
      });
      widget.onNavigationChanged?.call();
      return;
    }
    if (_isSearching) {
      setState(() {
        _isSearching = false;
        _searchQuery = '';
        _searchController.clear();
      });
      widget.onNavigationChanged?.call();
      return;
    }
    _navigateUp();
  }

  void toggleSearch() {
    setState(() => _isSearching = true);
    widget.onNavigationChanged?.call();
  }

  void goHome() {
    if (widget.isWorkplaceTab) {
      setState(() {
        _atShortcutsList = true;
        _activeShortcutRoot = null;
      });
      widget.onNavigationChanged?.call();
      return;
    }
    _loadDirectory(widget.rootPath);
  }

  void enterSelectionMode() {
    if (widget.isWorkplaceTab && _atShortcutsList) {
      showMessageDialog(context, 'Open a shortcut first to select files inside it.');
      return;
    }
    setState(() => _selectionModeActive = true);
    widget.onNavigationChanged?.call();
  }

  void showSortSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            const ListTile(title: Text('Sort by', style: TextStyle(fontWeight: FontWeight.bold))),
            for (final mode in SortMode.values) _sortTile(mode),
          ],
        ),
      ),
    );
  }

  Widget _sortTile(SortMode mode) {
    return ListTile(
      leading: Icon(
        _sortMode == mode ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
        size: 20,
      ),
      title: Text(mode.label),
      onTap: () {
        setState(() => _sortMode = mode);
        Navigator.pop(context);
      },
    );
  }

  void showCreateSheet() {
    if (widget.isWorkplaceTab && _atShortcutsList) {
      showMessageDialog(context, 'Open a shortcut first to create files inside it.');
      return;
    }
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.note_add_outlined),
              title: const Text('New File'),
              onTap: () {
                Navigator.pop(ctx);
                _createNewFile();
              },
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('New File from Template'),
              onTap: () {
                Navigator.pop(ctx);
                _createNewFileFromTemplate();
              },
            ),
            ListTile(
              leading: const Icon(Icons.create_new_folder_outlined),
              title: const Text('New Folder'),
              onTap: () {
                Navigator.pop(ctx);
                _createNewFolder();
              },
            ),
            ListTile(
              leading: const Icon(Icons.integration_instructions_outlined, color: Color(0xFF16A34A)),
              title: const Text('Git Init / Make GitHub Project'),
              subtitle: Text(_folderTitle, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () async {
                Navigator.pop(ctx);
                await showGitSetupDialog(context, folderPath: _currentPath);
              },
            ),
            ListTile(
              leading: const Icon(Icons.cloud_upload_rounded, color: Color(0xFF16A34A)),
              title: const Text('Push This Folder to GitHub'),
              subtitle: Text(_folderTitle, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () async {
                Navigator.pop(ctx);
                await showRepoPushDialog(context, folderPath: _currentPath);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- Open (smart dispatch by file type) ----------------

  static const _imageExtensions = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'};

  Future<void> _openInEditor(FileEntry entry, {bool forceReadOnly = false}) async {
    final ext = entry.extension;

    if (ext == 'zip') {
      final extracted = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => ArchiveViewerScreen(zipPath: entry.path)),
      );
      if (extracted == true && mounted) _loadDirectory(_currentPath);
      return;
    }

    if (_imageExtensions.contains(ext)) {
      final images = _visibleEntries.where((e) => !e.isDirectory && _imageExtensions.contains(e.extension)).toList();
      final startIndex = images.indexWhere((e) => e.path == entry.path);
      final changed = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => ImageViewerScreen(images: images, initialIndex: startIndex < 0 ? 0 : startIndex),
        ),
      );
      if (changed == true && mounted) _loadDirectory(_currentPath);
      return;
    }

    // Try as text/code first; anything that isn't (PDF, video, docx, apk...)
    // falls back to the system's own app via OpenFilex. Shows immediate
    // feedback the moment a file is tapped — reading runs on a background
    // isolate (see FileService.readFileAsString), so this spinner
    // animates smoothly the whole time instead of the tap appearing to
    // do nothing while a large file loads. Read happens before the size
    // check (not after) so a binary file never sees the "Large File"
    // warning meant for the editor — it never reaches the editor at all.
    if (!mounted) return;
    final busy = showBusyDialog(context, message: 'Opening ${entry.name}...');
    String? content;
    try {
      content = await _fileService.readFileAsString(entry.path);
    } catch (_) {
      content = null;
    }
    busy.close();

    if (content == null) {
      try {
        final result = await OpenFilex.open(entry.path);
        if (mounted && result.type != ResultType.done) {
          showMessageDialog(context, result.message, isError: true);
        }
      } catch (e) {
        if (mounted) {
          showMessageDialog(context, 'Could not open: $e', isError: true);
        }
      }
      return;
    }

    if (!mounted) return;
    if (entry.sizeBytes > _largeFileWarningBytes) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Large File'),
          content: Text('This is a huge file (${entry.readableSize}). This may take long to load.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('OK')),
          ],
        ),
      );
      if (proceed != true) return;
    }

    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditorScreen(filePath: entry.path, initialContent: content!, readOnly: forceReadOnly),
      ),
    );
    if (mounted) _loadDirectory(_currentPath);
  }

  // ---------------- Archive: extract / compress ----------------

  Future<void> _extractZip(FileEntry entry) async {
    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: 'Extracting...', cancelToken: cancelToken);
    try {
      final destination = await _archiveService.extractZip(
        entry.path,
        onProgress: (p) => progress.update(p),
        cancelToken: cancelToken,
      );
      progress.close();
      await _loadDirectory(_currentPath);
      if (mounted) {
        showMessageDialog(context, 'Extracted to ${destination.split('/').last}/');
      }
    } on OperationCancelledException {
      progress.close();
      if (mounted) await _loadDirectory(_currentPath);
    } catch (e) {
      progress.close();
      if (mounted) showMessageDialog(context, '❌ Extract failed: $e', isError: true);
    }
  }

  Future<void> _compressEntry(FileEntry entry) async {
    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: 'Compressing...', cancelToken: cancelToken);
    try {
      final zipPath = entry.isDirectory
          ? await _archiveService.compressFolder(entry.path, onProgress: (p) => progress.update(p), cancelToken: cancelToken)
          : await _archiveService.compressFile(entry.path, onProgress: (p) => progress.update(p), cancelToken: cancelToken);
      progress.close();
      await _loadDirectory(_currentPath);
      if (mounted) {
        showMessageDialog(context, 'Created ${zipPath.split('/').last}');
      }
    } on OperationCancelledException {
      progress.close();
    } catch (e) {
      progress.close();
      if (mounted) showMessageDialog(context, '❌ Compress failed: $e', isError: true);
    }
  }

  Future<void> _compressSelected() async {
    final entries = _allEntries.where((e) => _selectedPaths.contains(e.path)).toList();
    final paths = entries.map((e) => e.path).toList();
    setState(() {
      _selectionModeActive = false;
      _selectedPaths.clear();
    });
    widget.onNavigationChanged?.call();

    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: 'Compressing...', cancelToken: cancelToken);
    try {
      final zipPath = await _archiveService.compressMultiple(
        paths,
        _currentPath,
        onProgress: (p) => progress.update(p),
        cancelToken: cancelToken,
      );
      progress.close();
      await _loadDirectory(_currentPath);
      if (mounted) {
        showMessageDialog(context, 'Created ${zipPath.split('/').last}');
      }
    } on OperationCancelledException {
      progress.close();
    } catch (e) {
      progress.close();
      if (mounted) showMessageDialog(context, '❌ Compress failed: $e', isError: true);
    }
  }

  // ---------------- Create ----------------

  Future<void> _createNewFile() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New File'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'example.js', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.trim().isEmpty) return;
    final fileName = name.trim();

    try {
      await _fileService.createFile(_currentPath, fileName);
      await _loadDirectory(_currentPath);
      final newPath = '$_currentPath/$fileName';
      if (mounted) {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => EditorScreen(filePath: newPath, initialContent: '')),
        );
        if (mounted) _loadDirectory(_currentPath);
      }
    } catch (e) {
      if (mounted) showMessageDialog(context, '❌ $e', isError: true);
    }
  }

  Future<void> _createNewFileFromTemplate() async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            const ListTile(title: Text('Choose a Template', style: TextStyle(fontWeight: FontWeight.bold))),
            const Divider(height: 1),
            ...TemplateService.templateFileNames.map(
              (name) => ListTile(
                leading: const Icon(Icons.description_outlined),
                title: Text(name),
                onTap: () => Navigator.pop(ctx, name),
              ),
            ),
          ],
        ),
      ),
    );
    if (chosen == null) return;

    final controller = TextEditingController(text: chosen);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New File from Template'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'File name', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.trim().isEmpty) return;
    final fileName = name.trim();

    try {
      final content = await _templateService.loadTemplateContent(chosen);
      await _fileService.createFile(_currentPath, fileName, content: content);
      await _loadDirectory(_currentPath);
      final newPath = '$_currentPath/$fileName';
      if (mounted) {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => EditorScreen(filePath: newPath, initialContent: content)),
        );
        if (mounted) _loadDirectory(_currentPath);
      }
    } catch (e) {
      if (mounted) showMessageDialog(context, '❌ $e', isError: true);
    }
  }

  Future<void> _createNewFolder() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'my-folder', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create')),
        ],
      ),
    );
    if (result == true && controller.text.trim().isNotEmpty) {
      try {
        await _fileService.createFolder(_currentPath, controller.text.trim());
        await _loadDirectory(_currentPath);
      } catch (e) {
        if (mounted) showMessageDialog(context, '❌ $e', isError: true);
      }
    }
  }

  // ---------------- Rename / Delete (single item) ----------------

  Future<void> _renameEntry(FileEntry entry) async {
    final controller = TextEditingController(text: entry.name);
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Rename')),
        ],
      ),
    );
    if (result == true && controller.text.trim().isNotEmpty) {
      try {
        await _fileService.rename(entry.path, entry.isDirectory, controller.text.trim());
        await _loadDirectory(_currentPath);
      } catch (e) {
        if (mounted) showMessageDialog(context, '❌ $e', isError: true);
      }
    }
  }

  Future<bool> _confirmIfNeeded(String title, String message) async {
    if (!_confirmBeforeDelete) return true;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return confirmed == true;
  }

  Future<void> _deleteEntry(FileEntry entry) async {
    if (!await _confirmIfNeeded('Delete?', '"${entry.name}" will be permanently deleted.')) return;
    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: 'Deleting...', cancelToken: cancelToken);
    try {
      await _fileService.delete(entry.path, entry.isDirectory, onProgress: (p) => progress.update(p), cancelToken: cancelToken);
      progress.close();
      await _loadDirectory(_currentPath);
    } on OperationCancelledException {
      progress.close();
      if (mounted) await _loadDirectory(_currentPath);
    } catch (e) {
      progress.close();
      if (mounted) showMessageDialog(context, '❌ $e', isError: true);
    }
  }

  // ---------------- Multi-select: cut / copy / paste / delete ----------------

  void _cutOrCopySelected({required bool isCut}) {
    final entries = _allEntries.where((e) => _selectedPaths.contains(e.path)).toList();
    widget.clipboard.set(entries, isCut);
    setState(() {
      _selectionModeActive = false;
      _selectedPaths.clear();
    });
    widget.onNavigationChanged?.call();
  }

  Future<void> _deleteSelected() async {
    final count = _selectedPaths.length;
    if (!await _confirmIfNeeded('Delete Selected?', '$count item(s) will be permanently deleted.')) return;

    final entries = _allEntries.where((e) => _selectedPaths.contains(e.path)).toList();
    setState(() {
      _selectionModeActive = false;
      _selectedPaths.clear();
    });
    widget.onNavigationChanged?.call();

    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: 'Deleting...', cancelToken: cancelToken);
    final failures = <String, Object>{};
    var succeeded = 0;
    var cancelledEarly = false;
    for (var i = 0; i < entries.length; i++) {
      if (cancelToken.isCancelled) {
        cancelledEarly = true;
        break;
      }
      final entry = entries[i];
      try {
        await _fileService.delete(
          entry.path,
          entry.isDirectory,
          onProgress: (p) => progress.update((i + p) / entries.length, detail: entry.name),
          cancelToken: cancelToken,
        );
        succeeded++;
      } on OperationCancelledException {
        cancelledEarly = true;
        break;
      } catch (e) {
        failures[entry.name] = e;
      }
    }
    progress.close();
    await _loadDirectory(_currentPath);
    if (mounted) {
      _showBatchResultDialog(action: 'delete', total: entries.length, succeeded: succeeded, failures: failures, cancelled: cancelledEarly);
    }
  }

  Future<void> _pasteClipboard() async {
    final items = widget.clipboard.entries;
    if (items == null || items.isEmpty) return;
    final isCut = widget.clipboard.isCut;

    final cancelToken = CancellationToken();
    final progress = showProgressDialog(context, title: isCut ? 'Moving...' : 'Copying...', cancelToken: cancelToken);
    final failures = <String, Object>{};
    var succeeded = 0;
    var cancelledEarly = false;
    for (var i = 0; i < items.length; i++) {
      if (cancelToken.isCancelled) {
        cancelledEarly = true;
        break;
      }
      final entry = items[i];
      void itemProgress(double p) => progress.update((i + p) / items.length, detail: entry.name);
      try {
        if (isCut) {
          await _fileService.moveEntry(entry.path, _currentPath, entry.isDirectory, onProgress: itemProgress, cancelToken: cancelToken);
        } else {
          await _fileService.copyEntry(entry.path, _currentPath, entry.isDirectory, onProgress: itemProgress, cancelToken: cancelToken);
        }
        succeeded++;
      } on OperationCancelledException {
        cancelledEarly = true;
        break;
      } catch (e) {
        failures[entry.name] = e;
      }
    }
    progress.close();
    // A cancelled/partial cut must not silently drop the un-pasted
    // remainder — only clear the clipboard once everything that was
    // going to be moved/copied actually finished.
    if (!cancelledEarly) widget.clipboard.clear();
    await _loadDirectory(_currentPath);
    if (mounted) {
      _showBatchResultDialog(action: isCut ? 'move' : 'copy', total: items.length, succeeded: succeeded, failures: failures, cancelled: cancelledEarly);
    }
  }

  /// One consolidated result dialog for a batch op — replaces popping a
  /// separate dialog per failed item mid-loop, which used to stack N
  /// non-dismissible dialogs on top of the still-running progress dialog
  /// (one per failure) that the user had to click through one at a time
  /// while the batch kept processing underneath. Silent on full success,
  /// same as a single-item delete/paste always was.
  void _showBatchResultDialog({
    required String action,
    required int total,
    required int succeeded,
    required Map<String, Object> failures,
    required bool cancelled,
  }) {
    if (failures.isEmpty && !cancelled) return;
    final lines = <String>[
      if (cancelled) 'Cancelled — $succeeded of $total item(s) finished before stopping.' else '$succeeded of $total item(s) $action succeeded.',
      if (failures.isNotEmpty) '',
      if (failures.isNotEmpty) 'Failed:',
      ...failures.entries.map((e) => '• ${e.key}: ${e.value}'),
    ];
    showMessageDialog(context, lines.join('\n'), isError: failures.isNotEmpty);
  }

  // ---------------- Per-item action sheet ----------------

  void _showEntryActionSheet(FileEntry entry) {
    if (widget.isWorkplaceTab && _atShortcutsList) {
      _showShortcutActionSheet(entry);
      return;
    }

    showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: Icon(entry.isDirectory ? Icons.folder_rounded : Icons.insert_drive_file_rounded),
              title: Text(entry.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: const Text('Choose an action'),
            ),
            const Divider(height: 1),
            if (!entry.isDirectory)
              ListTile(
                leading: const Icon(Icons.launch_rounded),
                title: const Text('Open in Editor'),
                onTap: () => Navigator.pop(ctx, 'open'),
              ),
            if (!entry.isDirectory && entry.extension != 'zip' && !_imageExtensions.contains(entry.extension))
              ListTile(
                leading: const Icon(Icons.lock_outline_rounded),
                title: const Text('Open Read-Only'),
                onTap: () => Navigator.pop(ctx, 'readonly'),
              ),
            if (entry.extension == 'zip')
              ListTile(
                leading: const Icon(Icons.unarchive_rounded),
                title: const Text('Extract Here'),
                onTap: () => Navigator.pop(ctx, 'extract'),
              ),
            ListTile(
              leading: const Icon(Icons.folder_zip_outlined),
              title: const Text('Compress to Zip'),
              onTap: () => Navigator.pop(ctx, 'compress'),
            ),
            if (entry.isDirectory)
              ListTile(
                leading: const Icon(Icons.cloud_upload_rounded, color: Color(0xFF16A34A)),
                title: const Text('Push to GitHub'),
                subtitle: const Text('Commits every file in this folder'),
                onTap: () => Navigator.pop(ctx, 'push'),
              ),
            if (entry.isDirectory)
              ListTile(
                leading: const Icon(Icons.bookmark_add_outlined),
                title: const Text('Add to Workplace'),
                onTap: () => Navigator.pop(ctx, 'addToWorkplace'),
              ),
            ListTile(
              leading: const Icon(Icons.check_box_outlined),
              title: const Text('Select'),
              onTap: () => Navigator.pop(ctx, 'select'),
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline_rounded),
              title: const Text('Rename'),
              onTap: () => Navigator.pop(ctx, 'rename'),
            ),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: const Text('Properties'),
              onTap: () => Navigator.pop(ctx, 'properties'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
              title: const Text('Delete'),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    ).then((action) async {
      switch (action) {
        case 'open':
          _openInEditor(entry);
          break;
        case 'readonly':
          _openInEditor(entry, forceReadOnly: true);
          break;
        case 'extract':
          await _extractZip(entry);
          break;
        case 'compress':
          await _compressEntry(entry);
          break;
        case 'push':
          await showRepoPushDialog(context, folderPath: entry.path);
          break;
        case 'addToWorkplace':
          await _addToWorkplace(entry);
          break;
        case 'select':
          setState(() {
            _selectionModeActive = true;
            _selectedPaths.add(entry.path);
          });
          widget.onNavigationChanged?.call();
          break;
        case 'properties':
          await showFileInfoDialog(context, entry);
          break;
        case 'rename':
          _renameEntry(entry);
          break;
        case 'delete':
          _deleteEntry(entry);
          break;
      }
    });
  }

  void _showShortcutActionSheet(FileEntry entry) {
    showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.folder_rounded),
              title: Text(entry.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: const Text('Choose an action'),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.launch_rounded),
              title: const Text('Open'),
              onTap: () => Navigator.pop(ctx, 'open'),
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline_rounded),
              title: const Text('Rename'),
              subtitle: const Text('Renames the real folder, not just the shortcut'),
              onTap: () => Navigator.pop(ctx, 'rename'),
            ),
            ListTile(
              leading: const Icon(Icons.bookmark_remove_outlined, color: Colors.redAccent),
              title: const Text('Remove from Workplace'),
              subtitle: const Text('Only unpins the shortcut — the real folder stays untouched'),
              onTap: () => Navigator.pop(ctx, 'remove'),
            ),
          ],
        ),
      ),
    ).then((action) async {
      switch (action) {
        case 'open':
          _openShortcut(entry);
          break;
        case 'rename':
          await _renameShortcut(entry);
          break;
        case 'remove':
          await _removeFromWorkplace(entry.path);
          break;
      }
    });
  }

  // ---------------- Build ----------------

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        _buildTopBar(scheme),
        Expanded(child: _buildBody(scheme)),
        ListenableBuilder(
          listenable: widget.clipboard,
          builder: (ctx, _) => _buildClipboardBar(scheme),
        ),
      ],
    );
  }

  Widget _buildTopBar(ColorScheme scheme) {
    if (_selectionModeActive) {
      return Material(
        color: scheme.surfaceContainerHigh,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: () {
                  setState(() {
                    _selectionModeActive = false;
                    _selectedPaths.clear();
                  });
                  widget.onNavigationChanged?.call();
                },
              ),
              Expanded(
                child: Text('${_selectedPaths.length} selected', style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              IconButton(
                tooltip: 'Cut',
                icon: const Icon(Icons.content_cut_rounded),
                onPressed: _selectedPaths.isEmpty ? null : () => _cutOrCopySelected(isCut: true),
              ),
              IconButton(
                tooltip: 'Copy',
                icon: const Icon(Icons.copy_rounded),
                onPressed: _selectedPaths.isEmpty ? null : () => _cutOrCopySelected(isCut: false),
              ),
              IconButton(
                tooltip: 'Compress to Zip',
                icon: const Icon(Icons.folder_zip_rounded),
                onPressed: _selectedPaths.isEmpty ? null : _compressSelected,
              ),
              IconButton(
                tooltip: 'Delete',
                icon: const Icon(Icons.delete_outline_rounded),
                onPressed: _selectedPaths.isEmpty ? null : _deleteSelected,
              ),
            ],
          ),
        ),
      );
    }

    if (_isSearching) {
      return Material(
        color: scheme.surfaceContainerHigh,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => handleBackPress(),
              ),
              Expanded(
                child: TextField(
                  controller: _searchController,
                  autofocus: true,
                  decoration: const InputDecoration(hintText: 'Search this folder...', border: InputBorder.none),
                  onChanged: (v) => setState(() => _searchQuery = v),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Material(
      color: scheme.surfaceContainerHigh,
      child: InkWell(
        onTap: _atRoot ? null : _navigateUp,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              if (!_atRoot) ...[
                const Icon(Icons.arrow_upward_rounded, size: 18),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  _folderTitle,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildClipboardBar(ColorScheme scheme) {
    if (!widget.clipboard.hasItems) return const SizedBox.shrink();
    if (widget.isWorkplaceTab && _atShortcutsList) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: scheme.surfaceContainerHighest,
      child: Row(
        children: [
          Icon(widget.clipboard.isCut ? Icons.content_cut_rounded : Icons.copy_rounded, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text('${widget.clipboard.entries!.length} item(s) ready to paste')),
          TextButton(onPressed: widget.clipboard.clear, child: const Text('Cancel')),
          const SizedBox(width: 4),
          FilledButton(onPressed: _pasteClipboard, child: const Text('Paste Here')),
        ],
      ),
    );
  }

  Widget _buildBody(ColorScheme scheme) {
    if (_permissionDenied) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.folder_off_rounded, size: 48, color: scheme.onSurfaceVariant),
              const SizedBox(height: 12),
              const Text('Storage permission needed to browse files.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () async {
                  final granted = await _fileService.ensureStoragePermission();
                  if (granted) {
                    _loadDirectory(_currentPath);
                  } else {
                    _fileService.openAppSettingsPage();
                  }
                },
                child: const Text('Grant Access'),
              ),
            ],
          ),
        ),
      );
    }

    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (widget.isWorkplaceTab && _atShortcutsList) {
      return _buildShortcutsList(scheme);
    }

    final visible = _visibleEntries;

    if (visible.isEmpty) {
      return Center(
        child: Text(
          _searchQuery.isNotEmpty ? 'No matches' : 'Empty folder',
          style: TextStyle(color: scheme.onSurfaceVariant),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _loadDirectory(_currentPath),
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        itemCount: visible.length,
        itemBuilder: (context, index) {
          final entry = visible[index];
          final selected = _selectedPaths.contains(entry.path);
          return FileListTile(
            entry: entry,
            isSelectionMode: _selectionModeActive,
            isSelected: selected,
            onTap: () {
              if (_selectionModeActive) {
                setState(() {
                  if (selected) {
                    _selectedPaths.remove(entry.path);
                  } else {
                    _selectedPaths.add(entry.path);
                  }
                });
              } else if (entry.isDirectory) {
                _loadDirectory(entry.path);
              } else {
                _openInEditor(entry);
              }
            },
            onLongPress: () {
              if (_selectionModeActive) return;
              _showEntryActionSheet(entry);
            },
          );
        },
      ),
    );
  }

  Widget _buildShortcutsList(ColorScheme scheme) {
    final query = _searchQuery.toLowerCase();
    final visible = query.isEmpty
        ? _shortcutEntries
        : _shortcutEntries.where((e) => e.name.toLowerCase().contains(query)).toList();

    if (visible.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.bookmark_border_rounded, size: 48, color: scheme.onSurfaceVariant),
              const SizedBox(height: 12),
              Text(
                _shortcutEntries.isEmpty ? 'No shortcuts yet' : 'No matches',
                style: TextStyle(color: scheme.onSurfaceVariant, fontWeight: FontWeight.w600),
              ),
              if (_shortcutEntries.isEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  'Long-press a folder in Storage or SD Card and tap "Add to Workplace".',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant.withOpacity(0.8)),
                ),
              ],
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadShortcuts,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        itemCount: visible.length,
        itemBuilder: (context, index) {
          final entry = visible[index];
          return FileListTile(
            entry: entry,
            onTap: () => _openShortcut(entry),
            onLongPress: () => _showShortcutActionSheet(entry),
          );
        },
      ),
    );
  }
}
