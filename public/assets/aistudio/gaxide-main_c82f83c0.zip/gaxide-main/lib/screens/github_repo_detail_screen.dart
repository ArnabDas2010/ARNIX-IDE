import 'package:flutter/material.dart';
import '../models/github_models.dart';
import '../services/github_api_service.dart';

/// Detail view for a single repo — pushed from the GitHub tab's repo
/// list. Deliberately scoped to what a developer glances at often
/// (recent commits, CI status, releases), not a full GitHub client.
class GithubRepoDetailScreen extends StatefulWidget {
  final String token;
  final GithubRepo repo;

  const GithubRepoDetailScreen({super.key, required this.token, required this.repo});

  @override
  State<GithubRepoDetailScreen> createState() => _GithubRepoDetailScreenState();
}

class _GithubRepoDetailScreenState extends State<GithubRepoDetailScreen> {
  final _api = GithubApiService();
  bool _loading = true;
  String? _commitsError;
  String? _runsError;
  String? _releasesError;
  List<GithubCommit> _commits = [];
  List<GithubActionRun> _runs = [];
  List<GithubRelease> _releases = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _commitsError = null;
      _runsError = null;
      _releasesError = null;
    });
    final owner = widget.repo.owner;
    final name = widget.repo.name;

    final results = await Future.wait([
      _api.fetchCommits(widget.token, owner, name),
      _api.fetchActionRuns(widget.token, owner, name),
      _api.fetchReleases(widget.token, owner, name),
    ]);

    if (!mounted) return;
    final commitsResult = results[0] as ApiResult<List<GithubCommit>>;
    final runsResult = results[1] as ApiResult<List<GithubActionRun>>;
    final releasesResult = results[2] as ApiResult<List<GithubRelease>>;

    setState(() {
      _loading = false;
      _commits = commitsResult.data ?? [];
      _runs = runsResult.data ?? [];
      _releases = releasesResult.data ?? [];
      _commitsError = commitsResult.success ? null : commitsResult.error;
      _runsError = runsResult.success ? null : runsResult.error;
      _releasesError = releasesResult.success ? null : releasesResult.error;
    });
  }

  Color _conclusionColor(GithubActionRun run) {
    if (run.status != 'completed') return Colors.amberAccent;
    switch (run.conclusion) {
      case 'success':
        return Colors.greenAccent;
      case 'failure':
        return Colors.redAccent;
      case 'cancelled':
        return Colors.grey;
      default:
        return Colors.blueGrey;
    }
  }

  IconData _conclusionIcon(GithubActionRun run) {
    if (run.status != 'completed') return Icons.autorenew_rounded;
    switch (run.conclusion) {
      case 'success':
        return Icons.check_circle_rounded;
      case 'failure':
        return Icons.cancel_rounded;
      default:
        return Icons.circle_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.repo.name, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.all(14),
                  children: [
                    if (widget.repo.description?.isNotEmpty == true) ...[
                      Text(widget.repo.description!, style: TextStyle(color: scheme.onSurfaceVariant)),
                      const SizedBox(height: 16),
                    ],
                    _sectionHeader('Latest Commits', Icons.commit_rounded),
                    if (_commitsError != null)
                      _errorRow(_commitsError!)
                    else if (_commits.isEmpty)
                      _emptyRow('No commits found')
                    else
                      ..._commits.map(_commitTile),
                    const SizedBox(height: 20),
                    _sectionHeader('GitHub Actions', Icons.play_circle_outline_rounded),
                    if (_runsError != null)
                      _errorRow(_runsError!)
                    else if (_runs.isEmpty)
                      _emptyRow('No workflow runs found')
                    else
                      ..._runs.map(_runTile),
                    const SizedBox(height: 20),
                    _sectionHeader('Latest Releases', Icons.local_offer_outlined),
                    if (_releasesError != null)
                      _errorRow(_releasesError!)
                    else if (_releases.isEmpty)
                      _emptyRow('No releases yet')
                    else
                      ..._releases.map(_releaseTile),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, IconData icon) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 18, color: scheme.primary),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _emptyRow(String text) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Text(text, style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant.withOpacity(0.7))),
    );
  }

  Widget _errorRow(String message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Text('⚠️ Couldn\'t load: $message', style: const TextStyle(fontSize: 12.5, color: Colors.redAccent)),
    );
  }

  Widget _commitTile(GithubCommit c) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      leading: const Icon(Icons.circle_outlined, size: 18),
      title: Text(c.message, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      subtitle: Text('${c.authorName} · ${c.sha}', style: const TextStyle(fontSize: 11)),
    );
  }

  Widget _runTile(GithubActionRun r) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      leading: Icon(_conclusionIcon(r), size: 18, color: _conclusionColor(r)),
      title: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      subtitle: Text(
        '${r.branch.isEmpty ? '' : '${r.branch} · '}${r.conclusion ?? r.status}',
        style: const TextStyle(fontSize: 11),
      ),
    );
  }

  Widget _releaseTile(GithubRelease r) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      leading: Icon(Icons.local_offer_outlined, size: 18, color: r.prerelease ? Colors.amberAccent : Colors.greenAccent),
      title: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      subtitle: Text(r.tagName, style: const TextStyle(fontSize: 11)),
    );
  }
}
