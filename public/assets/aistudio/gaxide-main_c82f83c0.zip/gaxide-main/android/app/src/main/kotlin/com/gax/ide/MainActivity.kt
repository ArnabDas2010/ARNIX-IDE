package com.gax.ide

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * SAF (Storage Access Framework) bridge for browsing/editing folders a
 * normal app can't otherwise reach — most notably Android/data and
 * Android/obb, blocked from direct java.io.File access on Android 11+.
 *
 * The technique: ACTION_OPEN_DOCUMENT_TREE with
 * DocumentsContract.EXTRA_INITIAL_URI hinting at Android/data — both are
 * plain, documented Android SDK APIs (see
 * developer.android.com/training/data-storage/shared/documents-files).
 * There is no path manipulation, no special characters, nothing hidden:
 * this is exactly what MiXplorer and other legitimate file managers do.
 * Google closed the *initial-location hint* specifically on stock
 * Android 13+ (it still works on plenty of real Android 11/12 devices),
 * so every method here is written to fail softly — return
 * null/empty/an error string to Dart — rather than assume success.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.gax.ide/saf"
    private val pickTreeRequestCode = 8241
    private var pendingPickResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "com.gax.ide/native_editor",
            NativeCodeEditorViewFactory(flutterEngine.dartExecutor.binaryMessenger),
        )
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "pickTree" -> pickTree(call.argument<String>("hint"), result)
                    "listPersistedTrees" -> result.success(listPersistedTrees())
                    "releaseTree" -> {
                        releaseTree(call.argument<String>("uri")!!)
                        result.success(null)
                    }
                    "listChildren" -> result.success(listChildren(call.argument<String>("uri")!!))
                    "readBytes" -> result.success(readBytes(call.argument<String>("uri")!!))
                    "writeBytes" -> {
                        writeBytes(call.argument<String>("uri")!!, call.argument<ByteArray>("bytes")!!)
                        result.success(null)
                    }
                    "createFile" -> result.success(
                        createDocument(call.argument<String>("parentUri")!!, call.argument<String>("name")!!, "application/octet-stream")
                    )
                    "createDirectory" -> result.success(
                        createDocument(call.argument<String>("parentUri")!!, call.argument<String>("name")!!, DocumentsContract.Document.MIME_TYPE_DIR)
                    )
                    "deleteDocument" -> {
                        DocumentsContract.deleteDocument(contentResolver, Uri.parse(call.argument<String>("uri")!!))
                        result.success(null)
                    }
                    "renameDocument" -> {
                        val newUri = DocumentsContract.renameDocument(
                            contentResolver,
                            Uri.parse(call.argument<String>("uri")!!),
                            call.argument<String>("newName")!!,
                        )
                        result.success(newUri?.toString())
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                // Never let a SAF failure crash the app — surface it to
                // Dart's own error-handling path instead (same
                // philosophy as the rest of the app: no raw crashes).
                result.error("SAF_ERROR", e.message, null)
            }
        }
    }

    private fun pickTree(hint: String?, result: MethodChannel.Result) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        if (hint != null) {
            // "primary" = the device's own internal storage volume, which
            // is where Android/data and Android/obb actually live in the
            // overwhelming majority of real devices (an SD card doesn't
            // get its own separate Android/data tree). If the OS ignores
            // this hint (Android 13+), it just opens the normal default
            // location instead — a harmless no-op, not a failure.
            val encoded = Uri.encode(hint) // e.g. "Android/data" -> "Android%2Fdata"
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse("content://com.android.externalstorage.documents/document/primary%3A$encoded"))
        }
        pendingPickResult = result
        try {
            startActivityForResult(intent, pickTreeRequestCode)
        } catch (e: Exception) {
            pendingPickResult = null
            result.error("SAF_ERROR", "Could not open the system folder picker: ${e.message}", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickTreeRequestCode) return
        val callback = pendingPickResult
        pendingPickResult = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            callback?.success(null) // user cancelled — not an error
            return
        }
        val uri = data.data!!
        // Persist across app restarts — without this the grant only
        // lasts for the current process lifetime.
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        callback?.success(uri.toString())
    }

    private fun listPersistedTrees(): List<Map<String, String>> {
        return contentResolver.persistedUriPermissions.map {
            mapOf("uri" to it.uri.toString(), "name" to friendlyName(it.uri))
        }
    }

    private fun friendlyName(uri: Uri): String {
        // "content://.../document/primary:Android/data" -> "Android/data"
        val docId = try {
            DocumentsContract.getTreeDocumentId(uri)
        } catch (e: Exception) {
            uri.lastPathSegment ?: uri.toString()
        }
        val colonIndex = docId.indexOf(':')
        return if (colonIndex >= 0) docId.substring(colonIndex + 1) else docId
    }

    private fun releaseTree(uriString: String) {
        val uri = Uri.parse(uriString)
        contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    }

    /**
     * Lists the direct children of a tree (root) or a specific document
     * within it. Uses a single ContentResolver query (not DocumentFile,
     * which does one round-trip PER child PER property) — matters on
     * this app's stated low-RAM target, where a folder with hundreds of
     * entries would otherwise mean hundreds of extra IPC round-trips.
     */
    private fun listChildren(uriString: String): List<Map<String, Any?>> {
        val uri = Uri.parse(uriString)
        val isTreeUri = uriString.contains("/tree/") && !uriString.contains("/document/")
        val parentDocId = if (isTreeUri) DocumentsContract.getTreeDocumentId(uri) else DocumentsContract.getDocumentId(uri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(uri, parentDocId)

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val results = mutableListOf<Map<String, Any?>>()
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(childrenUri, projection, null, null, null)
            while (cursor != null && cursor.moveToNext()) {
                val docId = cursor.getString(0)
                val name = cursor.getString(1) ?: docId
                val mime = cursor.getString(2)
                val size = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                val lastModified = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                val childUri = DocumentsContract.buildDocumentUriUsingTree(uri, docId)
                results.add(
                    mapOf(
                        "uri" to childUri.toString(),
                        "name" to name,
                        "isDirectory" to (mime == DocumentsContract.Document.MIME_TYPE_DIR),
                        "size" to size,
                        "lastModified" to lastModified,
                    )
                )
            }
        } finally {
            cursor?.close()
        }
        return results
    }

    private fun readBytes(uriString: String): ByteArray {
        val uri = Uri.parse(uriString)
        return contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw Exception("Could not open this file for reading.")
    }

    private fun writeBytes(uriString: String, bytes: ByteArray) {
        val uri = Uri.parse(uriString)
        // "wt" = write + truncate — without truncate, writing shorter
        // content than what's already there would leave old bytes
        // trailing at the end of the file.
        contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            ?: throw Exception("Could not open this file for writing.")
    }

    private fun createDocument(parentUriString: String, name: String, mimeType: String): String {
        val parentUri = Uri.parse(parentUriString)
        val isTreeUri = parentUriString.contains("/tree/") && !parentUriString.contains("/document/")
        val parentDocId = if (isTreeUri) DocumentsContract.getTreeDocumentId(parentUri) else DocumentsContract.getDocumentId(parentUri)
        val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(parentUri, parentDocId)
        val newUri = DocumentsContract.createDocument(contentResolver, parentDocUri, mimeType, name)
            ?: throw Exception("Could not create \"$name\" — the system denied it.")
        return newUri.toString()
    }
}
