import 'package:flutter/material.dart';
import '../models/gaxide_project.dart';
import '../services/file_service.dart';
import '../services/gaxide_project_service.dart';
import '../services/git_service.dart';
import '../services/github_service.dart';
import '../services/prefs_service.dart';
import 'message_dialog.dart';
import 'progress_dialog.dart';

const _stickyCommitTag = 'Updated/Modified by GAX IDE';

/// One row in the changed-files list shown before a push.
class _ChangeRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String path;
  const _ChangeRow({required this.icon, required this.color, required this.path});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(path, style: const TextStyle(fontSize: 12.5, fontFamily: 'monospace'),
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }
}

/// "Git Init / Make GitHub Project" — one-time (or reconfigurable) setup
/// for a folder's GitHub push identity, reached from the FAB.
///
/// Auto-detects an existing `.git` folder. If found, a checkbox lets the
/// person choose: use that `.git` folder's own remote/branch (ticked), or
/// ignore it and create a `.gaxide` file with manually-entered details
/// instead (unticked — the default, so a folder with `.git` isn't forced
/// into git-based tracking just because the folder happens to have one).
/// If no `.git` exists at all, the checkbox is skipped entirely and it
/// goes straight to the `.gaxide` fields.
///
/// Nothing here pushes anything — this only saves the configuration that
/// showRepoPushDialog will later read.
Future<void> showGitSetupDialog(BuildContext context, {required String folderPath}) async {
  final gitService = GitService();
  final gaxideService = GaxideProjectService();
  final prefsService = PrefsService();
  final githubService = GithubService();

  final hasGit = await gitService.isGitRepo(folderPath);
  final gitInfo = hasGit ? await gitService.readRepoInfo(folderPath) : null;
  final existingGaxide = await gaxideService.read(folderPath);
  final config = await prefsService.loadConfig();

  if (!context.mounted) return;

  bool useGitFolder = false;
  bool usernameEditedByUser = existingGaxide != null && existingGaxide.username.isNotEmpty;
  bool usernameFetchStarted = false;
  String? errorText;

  final projectNameController =
      TextEditingController(text: existingGaxide?.name ?? folderPath.split('/').last);
  final repoController = TextEditingController(text: existingGaxide?.repoName ?? gitInfo?.repo ?? '');
  final branchController = TextEditingController(text: existingGaxide?.branch ?? gitInfo?.branch ?? 'main');
  final usernameController = TextEditingController(text: existingGaxide?.username ?? '');

  void fetchUsernameInBackground(void Function(void Function()) setDialogState) {
    if (config.token.isEmpty) return;
    githubService.fetchAuthenticatedUsername(config.token).then((login) {
      if (login != null && login.isNotEmpty && !usernameEditedByUser) {
        setDialogState(() => usernameController.text = login);
      }
    });
  }

  await showDialog<void>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setDialogState) {
        if (!usernameFetchStarted) {
          usernameFetchStarted = true;
          fetchUsernameInBackground(setDialogState);
        }
        final scheme = Theme.of(ctx).colorScheme;

        return AlertDialog(
          title: const Text('Git Init / Make GitHub Project'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: scheme.surfaceContainerHigh,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(folderPath, style: const TextStyle(fontSize: 12), maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                ),
                if (hasGit) ...[
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: useGitFolder,
                    onChanged: (v) => setDialogState(() => useGitFolder = v ?? false),
                    title: const Text('Use this folder\'s .git'),
                    subtitle: Text(
                      gitInfo != null
                          ? 'Detected: ${gitInfo.fullName} (${gitInfo.branch})'
                          : 'A .git folder was found here, but its remote could not be read.',
                      style: const TextStyle(fontSize: 11.5),
                    ),
                  ),
                  const Divider(height: 20),
                ],
                if (!useGitFolder) ...[
                  TextField(
                    controller: projectNameController,
                    decoration: const InputDecoration(labelText: 'Project Name'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: usernameController,
                    onChanged: (_) => setDialogState(() => usernameEditedByUser = true),
                    decoration: const InputDecoration(labelText: 'GitHub Username', hintText: 'auto-fills from your token'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: repoController,
                    decoration: InputDecoration(
                      labelText: 'Repo Name',
                      hintText: 'repo-name',
                      // Shows exactly what actually gets used as the
                      // owner — the repo field itself only ever holds
                      // the bare name now, no more retyping the
                      // username a second time in "username/repo".
                      prefixText: '${usernameController.text.trim().isEmpty ? 'username' : usernameController.text.trim()}/',
                    ),
                    onChanged: (_) => setDialogState(() {}), // live-updates the prefixText above as the username changes
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: branchController,
                    decoration: const InputDecoration(labelText: 'Branch', hintText: 'main'),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Saved into a small .gaxide file in this folder — no .git needed.',
                    style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                  ),
                ],
                if (errorText != null) ...[
                  const SizedBox(height: 10),
                  Text(errorText!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(
              child: Text(useGitFolder ? 'Use .git Folder' : 'Save'),
              onPressed: () async {
                if (useGitFolder) {
                  if (await gaxideService.exists(folderPath)) {
                    await gaxideService.delete(folderPath);
                  }
                  Navigator.pop(ctx);
                  if (context.mounted) {
                    showMessageDialog(context, "This folder's .git will be used for GitHub push.");
                  }
                  return;
                }

                final repoName = repoController.text.trim();
                if (repoName.isEmpty) {
                  setDialogState(() => errorText = 'Repo name is required');
                  return;
                }
                if (repoName.contains('/')) {
                  setDialogState(() => errorText = 'Just the repo name here — the username above is added automatically');
                  return;
                }
                if (branchController.text.trim().isEmpty) {
                  setDialogState(() => errorText = 'Branch is required');
                  return;
                }
                final owner = usernameController.text.trim();
                if (owner.isEmpty) {
                  setDialogState(() => errorText = 'GitHub username is required — wait for it to auto-fill, or type it in');
                  return;
                }

                final project = GaxideProject(
                  name: projectNameController.text.trim().isEmpty
                      ? folderPath.split('/').last
                      : projectNameController.text.trim(),
                  repo: '$owner/$repoName', // .gaxide's own format is untouched — this is built here, not typed by hand
                  branch: branchController.text.trim(),
                  username: owner,
                  createdAt: existingGaxide?.createdAt ?? DateTime.now().toIso8601String(),
                );
                await gaxideService.write(folderPath, project);
                Navigator.pop(ctx);
                if (context.mounted) {
                  showMessageDialog(context, 'Project configured — ready to push.');
                }
              },
            ),
          ],
        );
      },
    ),
  );
}

/// Push dialog for a folder that's already configured (via `.gaxide` or
/// `.git` — see [showGitSetupDialog]). No repo/branch/username fields
/// here anymore — those are already known — instead this opens straight
/// into "here's what changed since the last push" (diffed directly
/// against the real GitHub tree, by content hash) with a commit-message
/// field and a live progress bar once Push is tapped.
Future<void> showRepoPushDialog(BuildContext context, {required String folderPath}) async {
  final prefsService = PrefsService();
  final gitService = GitService();
  final fileService = FileService();
  final githubService = GithubService();
  final gaxideService = GaxideProjectService();

  final config = await prefsService.loadConfig();
  if (!context.mounted) return;
  if (config.token.isEmpty) {
    showMessageDialog(context, 'Set up your GitHub Token in Settings first.');
    return;
  }

  // .gaxide takes priority when present; otherwise fall back to an
  // actual .git folder (searching upward, same as before).
  final gaxideProject = await gaxideService.read(folderPath);
  String owner, repo, branch, authorName;
  if (gaxideProject != null) {
    owner = gaxideProject.owner;
    repo = gaxideProject.repoName;
    branch = gaxideProject.branch;
    authorName = gaxideProject.username;
    if (owner.isEmpty || owner == 'GAX IDE') {
      // A previous version of the Git Init form could save this
      // literal placeholder as the owner when the Username field was
      // still empty at Save time — every GitHub API call against it
      // 404s (there's no such account), which is why this specific
      // project could never push. Point at the actual fix instead of
      // letting it fail cryptically.
      if (context.mounted) {
        showMessageDialog(
          context,
          'This project\'s GitHub username wasn\'t saved correctly. Reopen "Git Init / Make GitHub Project" and make sure your username is filled in before saving.',
          isError: true,
        );
      }
      return;
    }
  } else {
    final gitRoot = await gitService.findNearestGitRoot(folderPath, stopAtPath: FileService.rootStoragePath);
    final repoInfo = gitRoot != null ? await gitService.readRepoInfo(gitRoot) : null;
    if (repoInfo == null) {
      if (context.mounted) {
        showMessageDialog(context, 'Not set up yet — use "Git Init / Make GitHub Project" from the ➕ menu first.');
      }
      return;
    }
    owner = repoInfo.owner;
    repo = repoInfo.repo;
    branch = repoInfo.branch;
    authorName = 'GAX IDE';
  }

  if (!context.mounted) return;

  // Collecting local files (reads every trackable file's bytes) and
  // checking GitHub for what's already there is 3+ sequential network
  // calls plus disk I/O — previously done with zero UI feedback before
  // the dialog even opened, so tapping "Push" looked like nothing was
  // happening for however long that took on a slow connection.
  final busy = showBusyDialog(context, message: 'Checking for changes...');
  List<MapEntry<String, List<int>>> files;
  Map<String, String> remoteTree;
  try {
    files = await () async {
      final ignoreDirs = (await prefsService.loadPerformancePrefs()).ignoreDirs;
      return fileService.collectFilesForPush(folderPath, ignoreDirs: ignoreDirs);
    }().timeout(
      const Duration(seconds: 45),
      onTimeout: () => throw Exception('Reading local files timed out — is the project unusually large, or something in it never-ending (e.g. a symlink loop)?'),
    );
    remoteTree = await githubService.fetchRemoteTree(token: config.token, owner: owner, repo: repo, branch: branch);
  } on RemoteTreeFetchException catch (e) {
    busy.close();
    if (context.mounted) showMessageDialog(context, '❌ $e', isError: true);
    return;
  } catch (e) {
    busy.close();
    if (context.mounted) showMessageDialog(context, '❌ Could not prepare the push: $e', isError: true);
    return;
  }
  busy.close();
  final diff = githubService.computeDiff(files, remoteTree);

  if (!context.mounted) return;
  if (!diff.hasChanges) {
    showMessageDialog(context, 'Nothing has changed since the last push.');
    return;
  }

  final commitController = TextEditingController();
  bool isPushing = false;
  double pushProgress = 0;

  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setDialogState) {
        final scheme = Theme.of(ctx).colorScheme;
        return PopScope(
          canPop: !isPushing,
          child: AlertDialog(
            title: Text('Push to $owner/$repo'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Branch: $branch', style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
                  const SizedBox(height: 10),
                  Text('${diff.changedCount} file(s) changed', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Container(
                    constraints: const BoxConstraints(maxHeight: 180),
                    decoration: BoxDecoration(
                      border: Border.all(color: scheme.outlineVariant.withOpacity(0.4)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ...diff.added.map(
                            (p) => _ChangeRow(icon: Icons.add_circle_outline, color: Colors.greenAccent, path: p),
                          ),
                          ...diff.modified.map(
                            (p) => _ChangeRow(icon: Icons.circle_outlined, color: Colors.amberAccent, path: p),
                          ),
                          ...diff.deleted.map(
                            (p) => _ChangeRow(icon: Icons.remove_circle_outline, color: Colors.redAccent, path: p),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: commitController,
                    enabled: !isPushing,
                    decoration: const InputDecoration(
                      labelText: 'Commit Message (optional)',
                      hintText: 'e.g. fixed login bug',
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '"($_stickyCommitTag)" is always added at the end.',
                    style: TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                  if (isPushing) ...[
                    const SizedBox(height: 14),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(value: pushProgress, minHeight: 8),
                    ),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        '${(pushProgress * 100).clamp(0, 100).toStringAsFixed(0)}%',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: isPushing ? null : () => Navigator.pop(ctx), child: const Text('Cancel')),
              FilledButton.icon(
                icon: isPushing
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.cloud_upload_rounded, size: 18),
                label: Text(isPushing ? 'Pushing...' : 'Push ${diff.changedCount} File(s)'),
                onPressed: isPushing
                    ? null
                    : () async {
                        setDialogState(() {
                          isPushing = true;
                          pushProgress = 0;
                        });

                        final userCommitMsg = commitController.text.trim();
                        final finalCommitMessage =
                            userCommitMsg.isEmpty ? _stickyCommitTag : '$userCommitMsg ($_stickyCommitTag)';

                        final result = await githubService.pushFolder(
                          token: config.token,
                          owner: owner,
                          repo: repo,
                          branch: branch,
                          files: files,
                          diff: diff,
                          commitMessage: finalCommitMessage,
                          authorName: authorName,
                          onProgress: (p) => setDialogState(() => pushProgress = p),
                        );

                        String finalMessage = result.message;
                        if (result.success) {
                          final stats = await githubService.computeDiffStats(
                            token: config.token,
                            owner: owner,
                            repo: repo,
                            localFiles: files,
                            remoteTree: remoteTree,
                            diff: diff,
                          );
                          final parts = <String>[];
                          if (stats.addedFiles > 0) parts.add('${stats.addedFiles} added');
                          if (stats.modifiedFiles > 0) parts.add('${stats.modifiedFiles} modified');
                          if (stats.deletedFiles > 0) parts.add('${stats.deletedFiles} deleted');
                          final lineSummary = (stats.linesAdded > 0 || stats.linesRemoved > 0)
                              ? '  (+${stats.linesAdded} / -${stats.linesRemoved} lines)'
                              : '';
                          finalMessage = 'Pushed to $owner/$repo ($branch)\n'
                              '${stats.totalFilesChanged} file(s) changed: ${parts.join(', ')}$lineSummary';

                          if (gaxideProject != null) {
                            final updated = gaxideProject.copyWithLastPush(
                              commitMessage: finalCommitMessage,
                              commitSha: result.commitSha ?? '',
                              pushTime: DateTime.now().toIso8601String(),
                              filesChanged: stats.totalFilesChanged,
                              linesAdded: stats.linesAdded,
                              linesRemoved: stats.linesRemoved,
                            );
                            await gaxideService.write(folderPath, updated);
                          }
                        }

                        if (ctx.mounted) Navigator.pop(ctx);
                        if (context.mounted) {
                          await showDialog<void>(
                            context: context,
                            builder: (resultCtx) => AlertDialog(
                              icon: Icon(
                                result.success ? Icons.check_circle_rounded : Icons.error_rounded,
                                color: result.success ? Colors.greenAccent : Colors.redAccent,
                                size: 34,
                              ),
                              title: Text(result.success ? 'Push Successful' : 'Push Failed'),
                              content: SingleChildScrollView(child: Text(finalMessage)),
                              actions: [
                                FilledButton(onPressed: () => Navigator.pop(resultCtx), child: const Text('OK')),
                              ],
                            ),
                          );
                        }
                      },
              ),
            ],
          ),
        );
      },
    ),
  );
}
