import 'dart:convert';
import 'dart:io';
import '../models/gaxide_project.dart';

/// Reads/writes the `.gaxide` file — a project's GitHub push identity
/// stored as plain JSON, independent of any actual `.git` folder.
class GaxideProjectService {
  static const fileName = '.gaxide';

  Future<bool> exists(String folderPath) => File('$folderPath/$fileName').exists();

  Future<GaxideProject?> read(String folderPath) async {
    try {
      final file = File('$folderPath/$fileName');
      if (!await file.exists()) return null;
      final content = await file.readAsString();
      return GaxideProject.fromJson(jsonDecode(content) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> write(String folderPath, GaxideProject project) async {
    final file = File('$folderPath/$fileName');
    const encoder = JsonEncoder.withIndent('  ');
    await file.writeAsString(encoder.convert(project.toJson()));
  }

  Future<void> delete(String folderPath) async {
    final file = File('$folderPath/$fileName');
    if (await file.exists()) await file.delete();
  }
}
