import 'package:flutter/material.dart';

/// Shows a simple message dialog with an OK button — the app-wide
/// replacement for SnackBar. Nothing shows at the bottom of the screen
/// anymore; every info/success/error message is a dialog the person has
/// to actively dismiss, so it's never missed.
Future<void> showMessageDialog(
  BuildContext context,
  String message, {
  bool isError = false,
  String? title,
}) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: Icon(
        isError ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
        color: isError ? Colors.redAccent : Colors.greenAccent,
        size: 32,
      ),
      title: title != null ? Text(title) : null,
      content: SingleChildScrollView(child: Text(message)),
      actions: [
        FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
      ],
    ),
  );
}
