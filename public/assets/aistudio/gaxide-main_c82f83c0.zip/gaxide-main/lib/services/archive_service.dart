import 'dart:io';
import 'package:archive/archive.dart';
import '../utils/cancellation_token.dart';

/// Zip compress/extract — the core ZArchiver-style feature. Uses the
/// `archive` package's stable core API (ZipDecoder/ZipEncoder over raw
/// bytes) rather than newer convenience helpers, so it stays correct
/// across package versions.
class ArchiveService {
  /// Decodes [zipPath] into an in-memory [Archive] WITHOUT writing anything
  /// to disk — powers the ZArchiver-style "browse a zip before extracting"
  /// viewer. Safe to call on large archives since only the central
  /// directory + requested entry bytes are ever materialized in memory.
  Future<Archive> decodeZip(String zipPath) async {
    final bytes = await File(zipPath).readAsBytes();
    return ZipDecoder().decodeBytes(bytes);
  }

  /// Extracts ONE already-decoded [file] straight into [destDir],
  /// flattening its path down to just the base file name. Used by the
  /// in-zip viewer's "Extract This File" action so a single file can be
  /// pulled out without extracting the whole archive. Auto-renames on a
  /// name collision (e.g. "notes (1).txt").
  Future<String> extractSingleFile(ArchiveFile file, String destDir) async {
    final name = file.name.split('/').last;
    var outPath = '$destDir/$name';
    var counter = 1;
    while (await File(outPath).exists()) {
      final dot = name.lastIndexOf('.');
      final base = dot == -1 ? name : name.substring(0, dot);
      final ext = dot == -1 ? '' : name.substring(dot);
      outPath = '$destDir/$base ($counter)$ext';
      counter++;
    }
    final data = file.content as List<int>;
    final outFile = File(outPath);
    await outFile.create(recursive: true);
    await outFile.writeAsBytes(data);
    return outPath;
  }

  /// Extracts [zipPath] into a sibling folder with the same name as the
  /// zip (minus its extension) — e.g. `project.zip` -> `project/`.
  /// Returns the path of the created folder. [onProgress] (0.0-1.0) is
  /// reported per entry extracted.
  Future<String> extractZip(String zipPath, {void Function(double progress)? onProgress, CancellationToken? cancelToken}) async {
    final zipFile = File(zipPath);
    final bytes = await zipFile.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);

    final parentDir = zipPath.substring(0, zipPath.lastIndexOf('/'));
    final baseName = zipPath.split('/').last;
    final folderName = baseName.toLowerCase().endsWith('.zip')
        ? baseName.substring(0, baseName.length - 4)
        : baseName;
    final destination = '$parentDir/$folderName';

    final total = archive.isEmpty ? 1 : archive.length;
    var done = 0;
    try {
      for (final entry in archive) {
        cancelToken?.throwIfCancelled();
        final outPath = '$destination/${entry.name}';
        if (entry.isFile) {
          final data = entry.content as List<int>;
          final outFile = File(outPath);
          await outFile.create(recursive: true);
          await outFile.writeAsBytes(data);
        } else {
          await Directory(outPath).create(recursive: true);
        }
        done++;
        onProgress?.call((done / total).clamp(0.0, 1.0));
      }
    } on OperationCancelledException {
      // Leave nothing half-extracted behind for the user to trip over.
      final destDir = Directory(destination);
      if (await destDir.exists()) await destDir.delete(recursive: true);
      rethrow;
    }
    onProgress?.call(1);
    return destination;
  }

  /// Compresses a single folder into a `<folderName>.zip` sitting next to
  /// it (in its parent directory). Auto-increments the name if that zip
  /// already exists, rather than silently overwriting it.
  Future<String> compressFolder(String folderPath, {void Function(double progress)? onProgress, CancellationToken? cancelToken}) async {
    final name = folderPath.split('/').last;
    final parentDir = folderPath.substring(0, folderPath.lastIndexOf('/'));
    final outputZipPath = await _uniqueZipPath(parentDir, name);
    await _writeZip({folderPath: name}, outputZipPath, onProgress: onProgress, cancelToken: cancelToken);
    return outputZipPath;
  }

  /// Compresses a single file into a `<fileName>.zip` sitting next to it.
  /// Auto-increments the name if that zip already exists, rather than
  /// silently overwriting it.
  Future<String> compressFile(String filePath, {void Function(double progress)? onProgress, CancellationToken? cancelToken}) async {
    final name = filePath.split('/').last;
    final parentDir = filePath.substring(0, filePath.lastIndexOf('/'));
    final outputZipPath = await _uniqueZipPath(parentDir, name);
    await _writeZip({filePath: name}, outputZipPath, onProgress: onProgress, cancelToken: cancelToken);
    return outputZipPath;
  }

  /// Compresses several files/folders (multi-select) into one zip named
  /// `Archive.zip` in [destinationDir].
  Future<String> compressMultiple(
    List<String> paths,
    String destinationDir, {
    void Function(double progress)? onProgress,
    CancellationToken? cancelToken,
  }) async {
    final entries = <String, String>{
      for (final path in paths) path: path.split('/').last,
    };
    final outputZipPath = await _uniqueZipPath(destinationDir, 'Archive');
    await _writeZip(entries, outputZipPath, onProgress: onProgress, cancelToken: cancelToken);
    return outputZipPath;
  }

  /// Resolves a `.zip` path that doesn't collide with an existing file —
  /// `name.zip`, then `name (1).zip`, `name (2).zip`, etc.
  Future<String> _uniqueZipPath(String destDir, String baseName) async {
    var outputZipPath = '$destDir/$baseName.zip';
    var counter = 1;
    while (await File(outputZipPath).exists()) {
      outputZipPath = '$destDir/$baseName ($counter).zip';
      counter++;
    }
    return outputZipPath;
  }

  Future<int> _countFiles(String path) async {
    final type = await FileSystemEntity.type(path);
    if (type == FileSystemEntityType.file) return 1;
    if (type != FileSystemEntityType.directory) return 0;
    var count = 0;
    await for (final child in Directory(path).list(recursive: true, followLinks: false)) {
      if (child is File) count++;
    }
    return count;
  }

  /// [sourcesWithArcName] maps an absolute source path (file or folder) to
  /// the name/prefix it should have inside the zip. [onProgress] covers
  /// the file-gathering phase (reading each source file into memory) as
  /// 0-90%; the final single-pass zip encode + disk write — which can't
  /// be subdivided further — fills the last 10%.
  Future<void> _writeZip(
    Map<String, String> sourcesWithArcName,
    String outputZipPath, {
    void Function(double progress)? onProgress,
    CancellationToken? cancelToken,
  }) async {
    final archive = Archive();

    var total = 0;
    for (final sourcePath in sourcesWithArcName.keys) {
      total += await _countFiles(sourcePath);
    }
    if (total == 0) total = 1;
    var done = 0;
    void tick() {
      done++;
      onProgress?.call(((done / total) * 0.9).clamp(0.0, 0.9));
    }

    Future<void> walk(Directory dir, String arcPrefix) async {
      await for (final entity in dir.list(followLinks: false)) {
        cancelToken?.throwIfCancelled();
        final name = entity.path.split('/').last;
        final arcPath = '$arcPrefix/$name';
        if (entity is Directory) {
          await walk(entity, arcPath);
        } else if (entity is File) {
          final bytes = await entity.readAsBytes();
          archive.addFile(ArchiveFile(arcPath, bytes.length, bytes));
          tick();
        }
      }
    }

    for (final entry in sourcesWithArcName.entries) {
      cancelToken?.throwIfCancelled();
      final sourcePath = entry.key;
      final arcName = entry.value;
      final type = await FileSystemEntity.type(sourcePath);
      if (type == FileSystemEntityType.directory) {
        await walk(Directory(sourcePath), arcName);
      } else if (type == FileSystemEntityType.file) {
        final bytes = await File(sourcePath).readAsBytes();
        archive.addFile(ArchiveFile(arcName, bytes.length, bytes));
        tick();
      }
    }

    // Cancellation stops here on purpose: the actual zip-encode + disk
    // write below is one atomic call with no checkpoint to bail out at,
    // and it's working from an in-memory archive we already built —
    // cheaper to just let it finish than to discard that work.
    final zipData = ZipEncoder().encode(archive);
    if (zipData == null) {
      throw Exception('Failed to build the zip archive.');
    }
    final outFile = File(outputZipPath);
    await outFile.create(recursive: true);
    await outFile.writeAsBytes(zipData);
    onProgress?.call(1);
  }
}
