import 'dart:typed_data';
import 'package:flutter/services.dart';
import '../models/saf_document.dart';

/// Anything Android/data-specific hitting the OS's own restriction comes
/// back through here — never a crash, always something the UI can show
/// the user plainly (see MainActivity.kt's SAF_ERROR channel errors).
class SafException implements Exception {
  final String message;
  const SafException(this.message);
  @override
  String toString() => message;
}

class SafService {
  static const _channel = MethodChannel('com.gax.ide/saf');

  Future<T> _call<T>(String method, [Map<String, dynamic>? args]) async {
    try {
      return await _channel.invokeMethod<T>(method, args) as T;
    } on PlatformException catch (e) {
      throw SafException(e.message ?? 'SAF operation failed.');
    }
  }

  /// Launches the system's own folder picker, hinting at [hint] (e.g.
  /// "Android/data" or "Android/obb") as the starting location. Whether
  /// the OS actually honors that hint depends on the device's Android
  /// version/OEM — on newer stock Android it's silently ignored and the
  /// picker just opens its normal default location instead, which is a
  /// harmless fallback, not a failure. Returns the granted tree's URI,
  /// or null if the user backed out of the picker.
  Future<String?> pickTree({String? hint}) => _call<String?>('pickTree', {'hint': hint});

  /// Every tree this app currently holds a persisted grant for — lets
  /// the user reopen a previously-granted folder without going through
  /// the system picker again.
  Future<List<SafTree>> listPersistedTrees() async {
    final raw = await _call<List<Object?>>('listPersistedTrees');
    return raw.map((e) => SafTree.fromMap(e as Map<Object?, Object?>)).toList();
  }

  Future<void> releaseTree(String uri) => _call<void>('releaseTree', {'uri': uri});

  Future<List<SafDocument>> listChildren(String uri) async {
    final raw = await _call<List<Object?>>('listChildren', {'uri': uri});
    return raw.map((e) => SafDocument.fromMap(e as Map<Object?, Object?>)).toList();
  }

  Future<Uint8List> readBytes(String uri) async {
    final bytes = await _call<Uint8List>('readBytes', {'uri': uri});
    return bytes;
  }

  Future<void> writeBytes(String uri, Uint8List bytes) => _call<void>('writeBytes', {'uri': uri, 'bytes': bytes});

  Future<String> createFile(String parentUri, String name) => _call<String>('createFile', {'parentUri': parentUri, 'name': name});

  Future<String> createDirectory(String parentUri, String name) =>
      _call<String>('createDirectory', {'parentUri': parentUri, 'name': name});

  Future<void> deleteDocument(String uri) => _call<void>('deleteDocument', {'uri': uri});

  /// Renaming a SAF document can change its URI entirely (this is part
  /// of the platform contract, not a bug) — always use the returned
  /// value as the document's new identity, never assume the old URI
  /// still resolves to it afterward.
  Future<String> renameDocument(String uri, String newName) async {
    final result = await _call<String?>('renameDocument', {'uri': uri, 'newName': newName});
    return result ?? uri;
  }
}
