import 'dart:io';
import 'package:flutter/material.dart';
import '../services/file_service.dart';
import '../services/gaxide_project_service.dart';
import '../services/git_service.dart';
import '../services/prefs_service.dart';
import '../services/saf_service.dart';
import '../services/template_service.dart';
import '../widgets/repo_push_dialog.dart';
import '../widgets/message_dialog.dart';
import 'editor_screen.dart';
import 'folder_picker_screen.dart';
import 'project_browser_screen.dart';
import 'saf_browser_screen.dart';

class _ProjectInfo {
  final String path;
  final String name;
  final bool exists;
  final bool isGitRepo;
  final bool isGaxideProject;
  final String? lastPushSummary;

  const _ProjectInfo({
    required this.path,
    required this.name,
    required this.exists,
    required this.isGitRepo,
    required this.isGaxideProject,
    this.lastPushSummary,
  });
}

/// Project dashboard — the Workspace bottom-nav tab. Shows pinned
/// projects as cards (not a file list — that's what the Files tab is
/// for) with a git/.gaxide badge and, where available, a quick summary
/// of the last push. The FAB covers the four project-level actions:
/// opening an existing folder, creating a new file/folder, and setting
/// up GitHub tracking — all without needing to dig into the Files tab
/// first.
class WorkspaceScreen extends StatefulWidget {
  const WorkspaceScreen({super.key});

  @override
  State<WorkspaceScreen> createState() => WorkspaceScreenState();
}

class WorkspaceScreenState extends State<WorkspaceScreen> with AutomaticKeepAliveClientMixin {
  final _prefsService = PrefsService();
  final _fileService = FileService();
  final _gitService = GitService();
  final _saf = SafService();
  final _gaxideService = GaxideProjectService();
  final _templateService = TemplateService();

  List<_ProjectInfo> _projects = [];
  bool _loading = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  /// Seeds a default "Samples" project once, ever — moved here from the
  /// old Workplace-mode FileBrowserView tab, which no longer exists (this
  /// dashboard replaced it). If the user removes it later it stays gone;
  /// the templates themselves remain usable via "New File from Template"
  /// in the Files tab either way.
  Future<void> _seedSamplesProjectIfNeeded() async {
    if (await _prefsService.hasSeededSamplesShortcut()) return;
    try {
      final samplesPath = await _templateService.ensureSamplesFolderOnDisk();
      await _addProject(samplesPath);
    } catch (_) {
      // Non-fatal — templates remain usable via "New File from Template" either way.
    }
    await _prefsService.setSeededSamplesShortcut();
  }

  /// Public so RootScaffold can trigger a refresh whenever this tab is
  /// (re)selected — IndexedStack children only ever run initState()
  /// once, so this is how the project list picks up anything that
  /// changed while another tab was active.
  Future<void> refresh() => _load();

  /// Public so returning from a pushed screen (project browser, git
  /// setup, settings) can refresh the list/badges without recreating
  /// this tab.
  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    await _seedSamplesProjectIfNeeded();
    final paths = await _prefsService.loadWorkplaceShortcuts();
    final infos = <_ProjectInfo>[];

    for (final path in paths) {
      final exists = await Directory(path).exists();
      final isGit = exists ? await _gitService.isGitRepo(path) : false;
      final gaxide = exists ? await _gaxideService.read(path) : null;
      String? summary;
      if (gaxide?.lastPushTime != null) {
        final filesChanged = gaxide?.lastFilesChanged ?? 0;
        summary = 'Last push: $filesChanged file(s) changed';
      }
      infos.add(_ProjectInfo(
        path: path,
        name: path.split('/').last,
        exists: exists,
        isGitRepo: isGit,
        isGaxideProject: gaxide != null,
        lastPushSummary: summary,
      ));
    }

    if (mounted) {
      setState(() {
        _projects = infos;
        _loading = false;
      });
    }
  }

  Future<void> _openProject(_ProjectInfo project) async {
    if (!project.exists) {
      showMessageDialog(context, '"${project.name}" folder no longer exists — it may have been deleted or was on removable storage that\'s no longer connected.', isError: true);
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProjectBrowserScreen(folderPath: project.path, title: project.name)),
    );
    _load();
  }

  Future<void> _removeProject(String path) async {
    final shortcuts = await _prefsService.loadWorkplaceShortcuts();
    shortcuts.remove(path);
    await _prefsService.saveWorkplaceShortcuts(shortcuts);
    _load();
  }

  void _showProjectActions(_ProjectInfo project) {
    showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            if (!project.exists)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text(
                  'This folder is missing — it may have been deleted or was on removable storage.',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                ),
              ),
            if (project.exists) ...[
              ListTile(
                leading: const Icon(Icons.launch_rounded),
                title: const Text('Open'),
                onTap: () => Navigator.pop(ctx, 'open'),
              ),
              ListTile(
                leading: const Icon(Icons.integration_instructions_outlined),
                title: const Text('Git Init / Make GitHub Project'),
                onTap: () => Navigator.pop(ctx, 'gitinit'),
              ),
              ListTile(
                leading: const Icon(Icons.cloud_upload_rounded),
                title: const Text('Push to GitHub'),
                onTap: () => Navigator.pop(ctx, 'push'),
              ),
            ],
            ListTile(
              leading: const Icon(Icons.bookmark_remove_outlined, color: Colors.redAccent),
              title: const Text('Remove from Workspace'),
              subtitle: const Text('Only unpins — the real folder stays untouched'),
              onTap: () => Navigator.pop(ctx, 'remove'),
            ),
          ],
        ),
      ),
    ).then((action) async {
      switch (action) {
        case 'open':
          await _openProject(project);
          break;
        case 'gitinit':
          await showGitSetupDialog(context, folderPath: project.path);
          _load();
          break;
        case 'push':
          await showRepoPushDialog(context, folderPath: project.path);
          _load();
          break;
        case 'remove':
          await _removeProject(project.path);
          break;
      }
    });
  }

  Future<void> _addProject(String path) async {
    final shortcuts = await _prefsService.loadWorkplaceShortcuts();
    if (!shortcuts.contains(path)) {
      shortcuts.add(path);
      await _prefsService.saveWorkplaceShortcuts(shortcuts);
    }
  }

  Future<void> _openFolder() async {
    final picked = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const FolderPickerScreen()),
    );
    if (picked == null) return;
    await _addProject(picked);
    if (!mounted) return;
    await _openProject(_ProjectInfo(path: picked, name: picked.split('/').last, exists: true, isGitRepo: false, isGaxideProject: false));
  }

  /// Entry point for the SAF (Storage Access Framework) route into
  /// Android/data and Android/obb — see MainActivity.kt for the full
  /// explanation of the technique and why it's legitimate-but-not-
  /// guaranteed (depends on the device's Android version/OEM).
  Future<void> _openSafPicker() async {
    final persisted = await _saf.listPersistedTrees();

    if (!mounted) return;
    final choice = await showModalBottomSheet<({String action, String uri, String name})>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            if (persisted.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text('Previously granted', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
              ),
              ...persisted.map(
                (tree) => ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: Text(tree.name),
                  onTap: () => Navigator.pop(ctx, (action: 'reopen', uri: tree.uri, name: tree.name)),
                ),
              ),
              const Divider(),
            ],
            ListTile(
              leading: const Icon(Icons.data_object_rounded),
              title: const Text('Android/data'),
              onTap: () => Navigator.pop(ctx, (action: 'pick', uri: '', name: 'Android/data')),
            ),
            ListTile(
              leading: const Icon(Icons.inventory_2_outlined),
              title: const Text('Android/obb'),
              onTap: () => Navigator.pop(ctx, (action: 'pick', uri: '', name: 'Android/obb')),
            ),
            ListTile(
              leading: const Icon(Icons.folder_open_rounded),
              title: const Text('Choose any folder'),
              onTap: () => Navigator.pop(ctx, (action: 'pick', uri: '', name: '')),
            ),
          ],
        ),
      ),
    );
    if (choice == null || !mounted) return;

    if (choice.action == 'reopen') {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => SafBrowserScreen(treeUri: choice.uri, currentUri: choice.uri, title: choice.name)),
      );
      return;
    }

    final hint = choice.name;
    String? uri;
    try {
      uri = await _saf.pickTree(hint: hint.isEmpty ? null : hint);
    } catch (e) {
      if (mounted) showMessageDialog(context, '$e', isError: true);
      return;
    }
    if (uri == null) return; // user backed out of the system picker
    if (!mounted) return;
    final grantedUri = uri; // closures don't inherit the null-check promotion above
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SafBrowserScreen(treeUri: grantedUri, currentUri: grantedUri, title: hint.isEmpty ? 'Folder' : hint)),
    );
  }

  Future<void> _newProjectFolder() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Project Folder'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Folder name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;

    try {
      await _fileService.createFolder(FileService.rootStoragePath, name);
      final path = '${FileService.rootStoragePath}/$name';
      await _addProject(path);
      if (!mounted) return;
      await _openProject(_ProjectInfo(path: path, name: name, exists: true, isGitRepo: false, isGaxideProject: false));
    } catch (e) {
      if (mounted) showMessageDialog(context, '$e', isError: true);
    }
  }

  Future<void> _newFile() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New File'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'File name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;

    try {
      await _fileService.createFile(FileService.rootStoragePath, name);
      final path = '${FileService.rootStoragePath}/$name';
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => EditorScreen(filePath: path, initialContent: '')),
      );
    } catch (e) {
      if (mounted) showMessageDialog(context, '$e', isError: true);
    }
  }

  Future<void> _gitInitPickProject() async {
    if (_projects.isEmpty) {
      final picked = await Navigator.push<String>(
        context,
        MaterialPageRoute(builder: (_) => const FolderPickerScreen()),
      );
      if (picked == null) return;
      await _addProject(picked);
      if (!mounted) return;
      await showGitSetupDialog(context, folderPath: picked);
      _load();
      return;
    }

    final chosen = await showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            const ListTile(title: Text('Choose a Project', style: TextStyle(fontWeight: FontWeight.bold))),
            const Divider(height: 1),
            ..._projects.map(
              (p) => ListTile(
                leading: const Icon(Icons.folder_rounded, color: Color(0xFFFFC24B)),
                title: Text(p.name),
                onTap: () => Navigator.pop(ctx, p.path),
              ),
            ),
          ],
        ),
      ),
    );
    if (chosen == null) return;
    if (!mounted) return;
    await showGitSetupDialog(context, folderPath: chosen);
    _load();
  }

  void _showFabMenu() {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.folder_open_rounded),
              title: const Text('Open Folder'),
              onTap: () {
                Navigator.pop(ctx);
                _openFolder();
              },
            ),
            ListTile(
              leading: const Icon(Icons.note_add_outlined),
              title: const Text('New File'),
              onTap: () {
                Navigator.pop(ctx);
                _newFile();
              },
            ),
            ListTile(
              leading: const Icon(Icons.create_new_folder_outlined),
              title: const Text('New Folder'),
              onTap: () {
                Navigator.pop(ctx);
                _newProjectFolder();
              },
            ),
            ListTile(
              leading: const Icon(Icons.integration_instructions_outlined),
              title: const Text('Git Init / Make GitHub Project'),
              onTap: () {
                Navigator.pop(ctx);
                _gitInitPickProject();
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_shared_outlined),
              title: const Text('Android/data & obb Access'),
              subtitle: const Text('Best-effort — depends on Android version/device'),
              onTap: () {
                Navigator.pop(ctx);
                _openSafPicker();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Workspace')),
      floatingActionButton: FloatingActionButton(onPressed: _showFabMenu, child: const Icon(Icons.add_rounded)),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _load,
                child: _projects.isEmpty
                    ? ListView(
                        padding: const EdgeInsets.all(24),
                        children: [
                          const SizedBox(height: 80),
                          Icon(Icons.dashboard_customize_outlined, size: 56, color: scheme.onSurfaceVariant),
                          const SizedBox(height: 16),
                          Text(
                            'No projects yet',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: scheme.onSurface),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Tap + to open a folder or start a new project.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
                          ),
                        ],
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(14),
                        itemCount: _projects.length,
                        itemBuilder: (context, index) => _projectCard(scheme, _projects[index]),
                      ),
              ),
      ),
    );
  }

  Widget _projectCard(ColorScheme scheme, _ProjectInfo project) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: scheme.surfaceContainerHigh.withOpacity(0.6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openProject(project),
        onLongPress: () => _showProjectActions(project),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  project.exists ? Icons.folder_rounded : Icons.folder_off_outlined,
                  color: project.exists ? const Color(0xFFFFC24B) : scheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(project.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    const SizedBox(height: 3),
                    Text(
                      project.path,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant.withOpacity(0.8)),
                    ),
                    if (project.lastPushSummary != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        project.lastPushSummary!,
                        style: TextStyle(fontSize: 11, color: scheme.primary),
                      ),
                    ],
                  ],
                ),
              ),
              if (project.isGitRepo)
                Icon(Icons.cloud_done_outlined, size: 18, color: scheme.onSurfaceVariant.withOpacity(0.7))
              else if (project.isGaxideProject)
                Icon(Icons.integration_instructions_outlined, size: 18, color: scheme.onSurfaceVariant.withOpacity(0.7)),
            ],
          ),
        ),
      ),
    );
  }
}
