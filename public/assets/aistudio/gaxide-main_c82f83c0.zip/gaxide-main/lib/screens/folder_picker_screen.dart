import 'dart:io';
import 'package:flutter/material.dart';
import '../services/file_service.dart';

/// A deliberately minimal, folders-only browser for picking a folder to
/// add as a Workspace project — NOT the full file manager (no files
/// shown, no search/sort/select), so Workspace doesn't end up
/// re-implementing FileBrowserView.
class FolderPickerScreen extends StatefulWidget {
  final String initialPath;
  const FolderPickerScreen({super.key, this.initialPath = FileService.rootStoragePath});

  @override
  State<FolderPickerScreen> createState() => _FolderPickerScreenState();
}

class _FolderPickerScreenState extends State<FolderPickerScreen> {
  final _fileService = FileService();
  late String _currentPath = widget.initialPath;
  List<Directory> _folders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final entries = await Directory(_currentPath).list(followLinks: false).toList();
      final folders = entries.whereType<Directory>().where((d) => !d.path.split('/').last.startsWith('.')).toList()
        ..sort((a, b) => a.path.split('/').last.toLowerCase().compareTo(b.path.split('/').last.toLowerCase()));
      if (mounted) {
        setState(() {
          _folders = folders;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openFolder(String path) {
    setState(() => _currentPath = path);
    _load();
  }

  bool _goUp() {
    if (_currentPath == FileService.rootStoragePath || _currentPath == '/storage/emulated/0') return false;
    final parent = _currentPath.substring(0, _currentPath.lastIndexOf('/'));
    if (parent.isEmpty || !parent.startsWith('/storage')) return false;
    setState(() => _currentPath = parent);
    _load();
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return PopScope(
      canPop: _currentPath == widget.initialPath,
      onPopInvoked: (didPop) {
        if (didPop) return;
        if (!_goUp()) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(_currentPath.split('/').last, overflow: TextOverflow.ellipsis),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, _currentPath),
              child: const Text('Select This Folder'),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Icon(Icons.folder_open_rounded, size: 16, color: scheme.onSurfaceVariant),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        _currentPath,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _loading
                    ? const Center(child: CircularProgressIndicator())
                    : _folders.isEmpty
                        ? Center(
                            child: Text('No subfolders here', style: TextStyle(color: scheme.onSurfaceVariant)),
                          )
                        : ListView.builder(
                            itemCount: _folders.length,
                            itemBuilder: (context, index) {
                              final dir = _folders[index];
                              final name = dir.path.split('/').last;
                              return ListTile(
                                leading: const Icon(Icons.folder_rounded, color: Color(0xFFFFC24B)),
                                title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                trailing: const Icon(Icons.chevron_right_rounded),
                                onTap: () => _openFolder(dir.path),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
